"""URL configuration for Dwarkadhish Car Rental Project"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

from cars.views import car_list, car_detail, rent_car
from rentals.views import (
    contact, offers, compare_cars, corporate_booking,
    booking_confirmation, rentals_list, payment_page, process_payment,
    admin_dashboard, user_dashboard, payment_info
)
from accounts.views import register, profile, user_login as login_view, user_logout as logout_view
from .views import home

urlpatterns = [
    # Admin
    path('admin/', admin.site.urls),
    
    # Home and Main
    path('', home, name='home'),
    path('home/', home, name='home_alt'),
    
    # Cars
    path('cars/', car_list, name='car_list'),
    path('cars/<int:car_id>/', car_detail, name='car_detail'),
    path('rent-car/<int:car_id>/', rent_car, name='rent_car'),
    path('compare/', compare_cars, name='compare_cars'),
    
    # Rentals
    path('rentals/', include('rentals.urls', namespace='rentals')),
    path('booking/<str:booking_ref>/', booking_confirmation, name='booking_confirmation'),
    path('payment/<int:car_id>/', payment_page, name='payment_page'),
    path('process-payment/', process_payment, name='process_payment'),
    
    # Offers & Contact
    path('offers/', offers, name='offers'),
    path('contact/', contact, name='contact'),
    path('corporate/', corporate_booking, name='corporate_booking'),
    
    # User Accounts
    path('accounts/register/', register, name='register'),
    path('accounts/login/', login_view, name='login'),
    path('accounts/logout/', logout_view, name='logout'),
    path('accounts/profile/', profile, name='profile'),
    
    # Dashboards
    path('dashboard/', user_dashboard, name='dashboard'),
    path('admin-dashboard/', admin_dashboard, name='admin_dashboard'),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
