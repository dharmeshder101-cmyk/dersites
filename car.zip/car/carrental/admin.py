from django.contrib import admin

# Customize admin site - dwarkadhish car rental
admin.site.site_header = "dwarkadhish car rental"
admin.site.site_title = "dwarkadhish car rental"
admin.site.index_title = "Welcome to dwarkadhish car rental"

# Add custom CSS for admin
class CustomAdminSite(admin.AdminSite):
    site_header = "dwarkadhish car rental"
    site_title = "dwarkadhish car rental"
    index_title = "Welcome to dwarkadhish car rental"

    def get_app_list(self, request):
        app_list = super().get_app_list(request)
        # You can customize the app list here if needed
        return app_list

# Create custom admin site instance
custom_admin_site = CustomAdminSite(name='custom_admin')

# Register your models with the custom admin site if needed
# custom_admin_site.register(YourModel, YourModelAdmin)
