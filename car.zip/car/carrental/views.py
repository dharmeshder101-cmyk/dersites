from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from cars.models import Car, CarCategory
from rentals.models import Rental, BlogPost, Review
from accounts.models import UserProfile
from django.db.models import Avg, Count
from datetime import date

def home(request):
    # Featured cars (recently added)
    featured_cars = Car.objects.filter(available=True).order_by('-created_at')[:6]

    # Popular categories
    categories = CarCategory.objects.annotate(
        car_count=Count('car')
    ).filter(car_count__gt=0)[:4]

    # Recent blog posts
    blog_posts = BlogPost.objects.filter(published=True).order_by('-published_at')[:3]

    # Stats for homepage
    total_cars = Car.objects.filter(available=True).count()
    total_users = UserProfile.objects.count()
    total_bookings = Rental.objects.count()

    context = {
        'featured_cars': featured_cars,
        'categories': categories,
        'blog_posts': blog_posts,
        'total_cars': total_cars,
        'total_users': total_users,
        'total_bookings': total_bookings,
    }
    return render(request, 'home.html', context)

@login_required
def dashboard(request):
    featured_cars = Car.objects.filter(available=True)[:6]  # Show 6 featured cars
    
    # Get or create user profile
    profile, created = UserProfile.objects.get_or_create(user=request.user)
    
    # Get upcoming rentals (future rentals that are confirmed or active)
    upcoming_rentals = Rental.objects.filter(
        user=request.user,
        start_date__gte=date.today(),
        status__in=['confirmed', 'active']
    ).order_by('start_date')[:5]
    
    # Get recent rentals (all rentals ordered by creation)
    recent_rentals = Rental.objects.filter(
        user=request.user
    ).order_by('-created_at')[:5]
    
    # Get wallet balance and loyalty points
    wallet_balance = profile.wallet_balance or 0
    loyalty_points = profile.loyalty_points or 0
    
    context = {
        'featured_cars': featured_cars,
        'upcoming_rentals': upcoming_rentals,
        'recent_rentals': recent_rentals,
        'wallet_balance': wallet_balance,
        'loyalty_points': loyalty_points,
    }
    return render(request, 'dashboard.html', context)
