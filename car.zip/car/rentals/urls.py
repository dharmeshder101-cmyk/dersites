from django.urls import path
from . import views
from . import admin_views

app_name = 'rentals'

urlpatterns = [
    # Booking wizard
    path('book/<int:car_id>/', views.booking_wizard_step1, name='booking_wizard_step1'),
    path('book/step2/', views.booking_wizard_step2, name='booking_wizard_step2'),
    path('book/step3/', views.booking_wizard_step3, name='booking_wizard_step3'),
    path('booking/<str:booking_ref>/', views.booking_confirmation, name='booking_confirmation'),
    
    # Payment pages
    path('payment/<int:car_id>/', views.payment_page, name='payment_page'),
    path('process-payment/', views.process_payment, name='process_payment'),

    # Booking management
    path('', views.rentals_list, name='rentals'),
    path('cancel/<str:booking_ref>/', views.cancel_booking, name='cancel_booking'),
    path('review/<str:booking_ref>/', views.submit_review, name='submit_review'),

    # Contact page
    path('contact/', views.contact, name='contact'),
    path('payment-info/', views.payment_info, name='payment_info'),
    path('pay-remaining/<str:booking_ref>/', views.pay_remaining_amount, name='pay_remaining'),
    
    # Corporate booking
    path('corporate/', views.corporate_booking, name='corporate_booking'),
    
    # Offers page
    path('offers/', views.offers, name='offers'),
    
    # Admin management URLs
    path('admin/rental/<int:rental_id>/<str:action>/', admin_views.admin_rental_action, name='admin_rental_action'),
    path('admin/payment/<int:rental_id>/<str:action>/', admin_views.admin_payment_action, name='admin_payment_action'),
    path('admin/cancellation/<int:rental_id>/process/', admin_views.admin_process_cancellation, name='admin_process_cancellation'),
    path('admin/refund/<int:rental_id>/process/', admin_views.admin_process_refund, name='admin_process_refund'),
    path('admin/message/<int:message_id>/respond/', admin_views.admin_respond_message, name='admin_respond_message'),
    path('admin/coupon/manage/', admin_views.admin_manage_coupon, name='admin_manage_coupon'),
    path('admin/coupon/<int:coupon_id>/toggle/', admin_views.admin_toggle_coupon, name='admin_toggle_coupon'),
    
    # Enhanced Payment Management URLs
    path('admin/payment/<int:rental_id>/details/', admin_views.admin_payment_details, name='admin_payment_details'),
    path('admin/payment/<int:rental_id>/confirm-remaining/', admin_views.admin_confirm_remaining_amount, name='admin_confirm_remaining'),
    path('admin/payment/confirmations/', admin_views.admin_pending_confirmations, name='admin_pending_confirmations'),
    path('admin/payment/confirm/<int:transaction_id>/', admin_views.admin_confirm_payment, name='admin_confirm_payment'),
    
    # Payment Records - Main admin payment page showing full paid records
    path('admin/payments/payment/', admin_views.admin_full_payments, name='admin_full_payments'),
    
    # All Payment Confirmations - Shows all pending and confirmed payments
    path('admin/payments/all/', admin_views.admin_all_payment_confirmations, name='admin_all_payment_confirmations'),
]
