from django.db import models
from django.contrib.auth.models import User
from cars.models import Car
from django.utils import timezone
from datetime import timedelta

class Rental(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('confirmed', 'Confirmed'),
        ('active', 'Active'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled'),
    ]

    PAYMENT_STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('paid', 'Paid'),
        ('refunded', 'Refunded'),
        ('partially_refunded', 'Partially Refunded'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    car = models.ForeignKey(Car, on_delete=models.CASCADE)
    driver = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='driven_rentals')
    start_date = models.DateField()
    end_date = models.DateField()
    pickup_location = models.CharField(max_length=255, default='')
    dropoff_location = models.CharField(max_length=255, blank=True)
    total_days = models.PositiveIntegerField(default=1)
    base_price = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    discount_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    tax_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    total_price = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    security_deposit = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    
    # Deposit fields (10% of total price)
    deposit_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0, 
                                        help_text="10% of total price as deposit")
    deposit_paid = models.BooleanField(default=False, help_text="Whether deposit is paid")
    deposit_paid_at = models.DateTimeField(blank=True, null=True)
    deposit_returned = models.BooleanField(default=False)
    deposit_returned_at = models.DateTimeField(blank=True, null=True)
    
    # Full payment tracking
    full_payment_paid = models.BooleanField(default=False)
    full_payment_paid_at = models.DateTimeField(blank=True, null=True)
    pending_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    
    # Refund tracking for cancellations
    refund_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0,
                                       help_text="Refund amount after cancellation (10% deduction)")
    refund_processed = models.BooleanField(default=False)
    refund_processed_at = models.DateTimeField(blank=True, null=True)
    
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    payment_status = models.CharField(max_length=20, choices=PAYMENT_STATUS_CHOICES, default='pending')
    payment_method = models.CharField(max_length=50, blank=True, help_text="Payment method used (card, upi, netbanking, wallet, cash)")
    coupon_used = models.CharField(max_length=20, blank=True)
    add_ons = models.JSONField(default=list)  # list of add-on services
    special_requests = models.TextField(blank=True)
    booking_reference = models.CharField(max_length=20, blank=True, default='')
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.booking_reference} - {self.user.username} - {self.car.name}"

    def save(self, *args, **kwargs):
        if not self.booking_reference:
            self.booking_reference = f"DWK{timezone.now().strftime('%Y%m%d%H%M%S')}"
        super().save(*args, **kwargs)

    def calculate_total_price(self):
        # Calculate based on dates, add-ons, etc.
        days = (self.end_date - self.start_date).days + 1
        price = 0
        current_date = self.start_date
        for _ in range(days):
            price += self.car.get_current_price(current_date)
            current_date += timedelta(days=1)
        # Add add-ons
        for add_on in self.add_ons:
            price += add_on.get('price', 0)
        self.total_price = price - self.discount_amount + self.tax_amount
        return self.total_price

    class Meta:
        ordering = ['-created_at']

class AddOnService(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    active = models.BooleanField(default=True)

    def __str__(self):
        return self.name

class Review(models.Model):
    rental = models.OneToOneField(Rental, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    car = models.ForeignKey(Car, on_delete=models.CASCADE)
    rating = models.PositiveIntegerField(choices=[(i, i) for i in range(1, 6)])
    title = models.CharField(max_length=100)
    comment = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    verified = models.BooleanField(default=False)

    def __str__(self):
        return f"Review by {self.user.username} for {self.car.name}"

class Cancellation(models.Model):
    rental = models.OneToOneField(Rental, on_delete=models.CASCADE)
    reason = models.TextField()
    cancelled_at = models.DateTimeField(auto_now_add=True)
    refund_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    refund_processed = models.BooleanField(default=False)

class CorporateBooking(models.Model):
    company_name = models.CharField(max_length=100)
    contact_person = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=15)
    number_of_cars = models.PositiveIntegerField()
    start_date = models.DateField()
    end_date = models.DateField()
    special_requirements = models.TextField(blank=True)
    status = models.CharField(max_length=20, choices=[
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ], default='pending')
    created_at = models.DateTimeField(auto_now_add=True)

class BlogPost(models.Model):
    title = models.CharField(max_length=200)
    slug = models.SlugField(unique=True)
    content = models.TextField()
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    published = models.BooleanField(default=False)
    published_at = models.DateTimeField(blank=True, null=True)
    tags = models.JSONField(default=list)
    seo_title = models.CharField(max_length=60, blank=True)
    seo_description = models.CharField(max_length=160, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

class ContactMessage(models.Model):
    name = models.CharField(max_length=100, blank=True, null=True)
    email = models.EmailField(blank=True, null=True)
    phone = models.CharField(max_length=15, blank=True)
    subject = models.CharField(max_length=200, blank=True, null=True)
    message = models.TextField(blank=True, null=True)
    rating = models.PositiveIntegerField(choices=[(i, i) for i in range(1, 6)], blank=True, null=True)
    feedback = models.TextField(blank=True, null=True)
    admin_response = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    responded = models.BooleanField(default=False)

class NewsletterSubscription(models.Model):
    email = models.EmailField(unique=True)
    subscribed_at = models.DateTimeField(auto_now_add=True)
    active = models.BooleanField(default=True)
