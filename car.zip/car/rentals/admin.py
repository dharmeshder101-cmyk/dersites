from django.contrib import admin
from .models import Rental, AddOnService, Review, Cancellation, ContactMessage

class RentalAdmin(admin.ModelAdmin):
    list_display = ('booking_reference', 'user', 'car', 'start_date', 'end_date', 
                    'total_price', 'deposit_amount', 'deposit_paid', 'payment_status', 
                    'refund_amount', 'refund_processed', 'status', 'created_at')
    list_filter = ('status', 'payment_status', 'refund_processed', 'created_at', 'start_date', 'end_date')
    search_fields = ('booking_reference', 'user__username', 'user__email', 'car__name', 
                     'pickup_location', 'dropoff_location')
    readonly_fields = ('booking_reference', 'created_at', 'updated_at')
    date_hierarchy = 'created_at'
    list_per_page = 50
    list_editable = ('refund_processed',)
    
    fieldsets = (
        ('Booking Information', {
            'fields': ('booking_reference', 'user', 'car', 'driver', 'status', 'payment_status')
        }),
        ('Rental Period', {
            'fields': ('start_date', 'end_date', 'total_days')
        }),
        ('Pricing', {
            'fields': ('base_price', 'discount_amount', 'tax_amount', 'total_price', 
                       'security_deposit', 'deposit_amount', 'deposit_paid', 'deposit_returned')
        }),
        ('Full Payment', {
            'fields': ('full_payment_paid', 'full_payment_paid_at', 'pending_amount')
        }),
        ('Refund', {
            'fields': ('refund_amount', 'refund_processed', 'refund_processed_at')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )



class ReviewAdmin(admin.ModelAdmin):
    list_display = ('rental', 'user', 'car', 'rating', 'title', 'verified', 'created_at')
    list_filter = ('rating', 'verified', 'created_at')
    search_fields = ('user__username', 'car__name', 'title', 'comment')
    readonly_fields = ('created_at',)

class CancellationAdmin(admin.ModelAdmin):
    list_display = ('rental', 'cancelled_at', 'refund_amount', 'refund_processed')
    list_filter = ('refund_processed', 'cancelled_at')
    search_fields = ('rental__booking_reference', 'reason')
    readonly_fields = ('cancelled_at',)

class AddOnServiceAdmin(admin.ModelAdmin):
    list_display = ('name', 'price', 'description', 'active')
    list_filter = ('active',)
    search_fields = ('name', 'description')
    list_editable = ('active',)

class ContactMessageAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'subject', 'rating', 'responded', 'created_at')
    list_filter = ('responded', 'rating', 'created_at')
    search_fields = ('name', 'email', 'subject', 'message', 'feedback')
    readonly_fields = ('created_at',)
    list_editable = ('responded',)
    
    fieldsets = (
        ('Customer Info', {
            'fields': ('name', 'email', 'phone')
        }),
        ('Message', {
            'fields': ('subject', 'message', 'rating', 'feedback')
        }),
        ('Admin Response', {
            'fields': ('admin_response', 'responded')
        }),
        ('Timestamps', {
            'fields': ('created_at',),
            'classes': ('collapse',)
        }),
    )

# Register all models
admin.site.register(Rental, RentalAdmin)
admin.site.register(AddOnService, AddOnServiceAdmin)
admin.site.register(Review, ReviewAdmin)
admin.site.register(Cancellation, CancellationAdmin)
admin.site.register(ContactMessage, ContactMessageAdmin)
