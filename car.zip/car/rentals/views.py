from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q, Avg, Sum, Count
from django.core.paginator import Paginator
from django.contrib.auth.models import User
from .models import Rental, Review, AddOnService, Cancellation, CorporateBooking, BlogPost, ContactMessage
from cars.models import Car
from payments.models import Payment, Coupon, PaymentTransaction, PaymentConfirmation, RefundConfirmation
from accounts.models import UserProfile
from datetime import datetime, date, timedelta
from decimal import Decimal

# Import admin views
from .admin_views import (
    admin_dashboard,
    admin_rental_action,
    admin_payment_action,
    admin_process_cancellation,
    admin_process_refund,
    admin_respond_message,
    admin_manage_coupon,
    admin_toggle_coupon,
)

@login_required
def driver_dashboard(request):
    """Driver dashboard"""
    try:
        if request.user.userprofile.role != 'driver':
            messages.error(request, 'Access denied.')
            return redirect('home')
    except:
        messages.error(request, 'Profile not found.')
        return redirect('home')

    assigned_rentals = Rental.objects.filter(
        driver=request.user,
        status__in=['confirmed', 'active']
    ).order_by('start_date')

    completed_trips = Rental.objects.filter(
        driver=request.user,
        status='completed'
    ).order_by('-end_date')[:10]

    total_earnings = completed_trips.aggregate(
        total=Sum('total_price')
    )['total'] or 0

    context = {
        'assigned_rentals': assigned_rentals,
        'completed_trips': completed_trips,
        'total_earnings': total_earnings,
    }
    return render(request, 'rentals/driver_dashboard.html', context)

@login_required
def vendor_dashboard(request):
    """Vendor dashboard"""
    try:
        if request.user.userprofile.role != 'vendor':
            messages.error(request, 'Access denied.')
            return redirect('home')
    except:
        messages.error(request, 'Profile not found.')
        return redirect('home')

    cars = Car.objects.filter(vendor=request.user)
    total_cars = cars.count()
    available_cars = cars.filter(available=True).count()

    recent_rentals = Rental.objects.filter(
        car__vendor=request.user
    ).select_related('car', 'user').order_by('-created_at')[:10]

    completed_rentals = Rental.objects.filter(
        car__vendor=request.user,
        status='completed'
    )
    total_earnings = completed_rentals.aggregate(
        total=Sum('total_price')
    )['total'] or 0

    from django.db.models.functions import TruncMonth
    monthly_stats = completed_rentals.annotate(
        month=TruncMonth('created_at')
    ).values('month').annotate(
        count=Count('id'),
        revenue=Sum('total_price')
    ).order_by('-month')[:6]

    context = {
        'cars': cars,
        'total_cars': total_cars,
        'available_cars': available_cars,
        'recent_rentals': recent_rentals,
        'total_earnings': total_earnings,
        'monthly_stats': monthly_stats,
    }
    return render(request, 'rentals/vendor_dashboard.html', context)

@login_required
def admin_dashboard(request):
    """Admin custom dashboard - Comprehensive management panel"""
    try:
        if request.user.userprofile.role != 'admin':
            messages.error(request, 'Access denied.')
            return redirect('home')
    except:
        messages.error(request, 'Profile not found.')
        return redirect('home')

    filter_type = request.GET.get('filter', 'all')
    payment_filter = request.GET.get('payment_filter', 'all')
    refund_filter = request.GET.get('refund_filter', 'pending')
    message_filter = request.GET.get('message_filter', 'all')
    user_filter = request.GET.get('user_filter', 'all')
    car_filter = request.GET.get('car_filter', 'all')
    current_section = request.GET.get('section', 'overview')

    total_users = User.objects.count()
    total_cars = Car.objects.count()
    total_rentals = Rental.objects.count()
    total_bookings = total_rentals
    active_bookings = Rental.objects.filter(status__in=['confirmed', 'active']).count()
    total_revenue = Rental.objects.filter(status='completed').aggregate(total=models.Sum('total_price'))['total'] or 0
    total_deposits = Rental.objects.filter(deposit_paid=True).aggregate(total=models.Sum('deposit_amount'))['total'] or 0
    recent_rentals = Rental.objects.select_related('user', 'car').order_by('-created_at')[:10]
    pending_corporate = CorporateBooking.objects.filter(status='pending')

    if filter_type == 'all':
        all_rentals = Rental.objects.select_related('user', 'car').order_by('-created_at')
    else:
        all_rentals = Rental.objects.filter(status=filter_type).select_related('user', 'car').order_by('-created_at')
    pending_rentals = Rental.objects.filter(status='pending')
    confirmed_rentals = Rental.objects.filter(status='confirmed')
    completed_rentals_list = Rental.objects.filter(status='completed')

    if payment_filter == 'all':
        payment_rentals = Rental.objects.select_related('user', 'car').order_by('-created_at')
    elif payment_filter == 'deposit':
        payment_rentals = Rental.objects.filter(deposit_paid=True).select_related('user', 'car').order_by('-created_at')
    elif payment_filter == 'full':
        payment_rentals = Rental.objects.filter(full_payment_paid=True).select_related('user', 'car').order_by('-created_at')
    else:
        payment_rentals = Rental.objects.filter(payment_status='pending').select_related('user', 'car').order_by('-created_at')
    total_paid = Rental.objects.filter(payment_status='paid').aggregate(total=models.Sum('total_price'))['total'] or 0
    total_full_payments = Rental.objects.filter(full_payment_paid=True).aggregate(total=models.Sum('total_price'))['total'] or 0
    total_pending_payments = Rental.objects.filter(payment_status='pending').aggregate(total=models.Sum('total_price'))['total'] or 0

    pending_payment_transactions = PaymentTransaction.objects.filter(
        status='pending'
    ).select_related('rental', 'rental__car', 'rental__user').order_by('-created_at')
    
    confirmed_payment_transactions = PaymentTransaction.objects.filter(
        status__in=['confirmed', 'verified']
    ).select_related('rental', 'rental__car', 'rental__user').order_by('-created_at')
    
    pending_payment_confirmations = PaymentConfirmation.objects.filter(
        is_confirmed=False
    ).select_related('rental', 'rental__car', 'rental__user').order_by('-created_at')
    
    confirmed_payment_confirmations = PaymentConfirmation.objects.filter(
        is_confirmed=True
    ).select_related('rental', 'rental__car', 'rental__user').order_by('-confirmed_at')
    
    total_pending_amount = pending_payment_transactions.aggregate(models.Sum('amount'))['amount__sum'] or 0
    total_confirmed_amount = confirmed_payment_transactions.aggregate(models.Sum('amount'))['amount__sum'] or 0

    if refund_filter == 'pending':
        cancellation_rentals = Rental.objects.filter(
            status='cancelled',
            deposit_paid=True,
            refund_amount__gt=0,
            refund_processed=False
        ).select_related('user', 'car').order_by('-created_at')
    elif refund_filter == 'processed':
        cancellation_rentals = Rental.objects.filter(status='cancelled', refund_processed=True).select_related('user', 'car').order_by('-created_at')
    else:
        cancellation_rentals = Rental.objects.filter(status='cancelled').select_related('user', 'car').order_by('-created_at')
    pending_cancellations = Rental.objects.filter(status__in=['confirmed', 'pending'])
    completed_cancellations = Rental.objects.filter(status='cancelled', refund_processed=True)
    total_refunds_processed = Rental.objects.filter(refund_processed=True).aggregate(total=models.Sum('refund_amount'))['total'] or 0
    total_cancellation_charges = total_paid - total_refunds_processed

    if message_filter == 'unread':
        contact_messages = ContactMessage.objects.filter(responded=False).order_by('-created_at')
    elif message_filter == 'responded':
        contact_messages = ContactMessage.objects.filter(responded=True).order_by('-created_at')
    elif message_filter == 'feedback':
        contact_messages = ContactMessage.objects.filter(feedback__isnull=False).exclude(feedback='').order_by('-created_at')
    else:
        contact_messages = ContactMessage.objects.all().order_by('-created_at')
    total_messages = ContactMessage.objects.count()
    unread_messages = ContactMessage.objects.filter(responded=False)
    total_feedbacks = ContactMessage.objects.filter(feedback__isnull=False).exclude(feedback='').count()
    reviews = Review.objects.all()
    avg_rating = reviews.aggregate(Avg('rating'))['rating__avg'] or 0

    coupons = Coupon.objects.all().order_by('-created_at')
    today = date.today()

    if user_filter == 'all':
        all_users = UserProfile.objects.select_related('user').order_by('-user__date_joined')
    else:
        all_users = UserProfile.objects.filter(role=user_filter).select_related('user').order_by('-user__date_joined')

    if car_filter == 'available':
        all_cars = Car.objects.filter(available=True).order_by('-created_at')
    elif car_filter == 'rented':
        all_cars = Car.objects.filter(available=False).order_by('-created_at')
    else:
        all_cars = Car.objects.all().order_by('-created_at')

    from django.db.models.functions import TruncMonth
    monthly_stats = Rental.objects.annotate(month=TruncMonth('created_at')).values('month').annotate(
        count=models.Count('id'), revenue=models.Sum('total_price'), deposits=models.Sum('deposit_amount'), refunds=models.Sum('refund_amount')).order_by('-month')[:12]
    avg_booking_value = total_revenue / completed_rentals_list.count() if completed_rentals_list.exists() else 0
    avg_rental_days = Rental.objects.aggregate(Avg('total_days'))['total_days__avg'] or 0

    context = {
        'current_section': current_section, 'total_users': total_users, 'total_cars': total_cars, 'total_bookings': total_bookings,
        'active_bookings': active_bookings, 'total_revenue': total_revenue, 'total_deposits': total_deposits,
        'recent_rentals': recent_rentals, 'pending_corporate': pending_corporate, 'filter': filter_type,
        'all_rentals': all_rentals[:50], 'pending_rentals': pending_rentals, 'confirmed_rentals': confirmed_rentals,
        'payment_filter': payment_filter, 'payment_rentals': payment_rentals[:50], 'total_paid': total_paid,
        'total_full_payments': total_full_payments, 'total_pending_payments': total_pending_payments,
        'refund_filter': refund_filter, 'cancellation_rentals': cancellation_rentals[:50],
        'pending_cancellations': pending_cancellations, 'completed_cancellations': completed_cancellations,
        'total_refunds_processed': total_refunds_processed, 'total_cancellation_charges': total_cancellation_charges,
        'message_filter': message_filter, 'contact_messages': contact_messages[:20], 'total_messages': total_messages,
        'unread_messages': unread_messages, 'total_feedbacks': total_feedbacks, 'avg_rating': avg_rating,
        'coupons': coupons, 'today': today, 'user_filter': user_filter, 'all_users': all_users[:50],
        'car_filter': car_filter, 'all_cars': all_cars[:50], 'completed_rentals': completed_rentals,
        'avg_booking_value': avg_booking_value, 'avg_rental_days': avg_rental_days, 'monthly_stats': list(monthly_stats),
        
        'pending_payment_transactions': pending_payment_transactions,
        'confirmed_payment_transactions': confirmed_payment_transactions,
        'pending_payment_confirmations': pending_payment_confirmations,
        'confirmed_payment_confirmations': confirmed_payment_confirmations,
        'total_pending_amount': total_pending_amount,
        'total_confirmed_amount': total_confirmed_amount,
        
        'pending_full_payments': Rental.objects.filter(
            deposit_paid=True,
            full_payment_paid=False,
            pending_amount__gt=0,
            status__in=['pending', 'confirmed']
        ).select_related('car', 'user').order_by('-created_at'),
    }
    return render(request, 'rentals/admin_dashboard.html', context)


@login_required
def admin_rental_action(request, rental_id, action):
    """Handle admin actions on rentals"""
    try:
        if request.user.userprofile.role != 'admin':
            messages.error(request, 'Access denied.')
            return redirect('home')
    except:
        messages.error(request, 'Profile not found.')
        return redirect('home')
    
    rental = get_object_or_404(Rental, id=rental_id)
    if action == 'confirm':
        rental.status = 'confirmed'
        rental.payment_status = 'paid'
        rental.deposit_amount = rental.total_price * Decimal('0.10')
        rental.save()
        messages.success(request, f'Booking {rental.booking_reference} confirmed!')
    elif action == 'start':
        rental.status = 'active'
        rental.save()
        messages.success(request, f'Rental {rental.booking_reference} started!')
    elif action == 'complete':
        rental.status = 'completed'
        rental.payment_status = 'paid'
        rental.save()
        messages.success(request, f'Rental {rental.booking_reference} completed!')
    elif action == 'cancel':
        if rental.payment_status == 'paid':
            cancellation_charge = rental.total_price * Decimal('0.10')
            rental.refund_amount = rental.total_price - cancellation_charge
            rental.refund_processed = True
            rental.payment_status = 'refunded'
        rental.status = 'cancelled'
        rental.save()
        messages.success(request, f'Booking {rental.booking_reference} cancelled! Refund: Rs.{rental.refund_amount}')
    return redirect('admin_dashboard')


@login_required
def admin_payment_action(request, rental_id, action):
    """Handle payment actions"""
    try:
        if request.user.userprofile.role != 'admin':
            messages.error(request, 'Access denied.')
            return redirect('home')
    except:
        messages.error(request, 'Profile not found.')
        return redirect('home')
    
    rental = get_object_or_404(Rental, id=rental_id)
    if action == 'deposit-paid':
        rental.deposit_paid = True
        rental.deposit_paid_at = datetime.now()
        rental.deposit_amount = rental.total_price * Decimal('0.10')
        rental.pending_amount = rental.total_price - rental.deposit_amount
        rental.payment_status = 'paid'
        rental.save()
        messages.success(request, f'Deposit marked as paid for {rental.booking_reference}')
    elif action == 'full-payment':
        rental.full_payment_paid = True
        rental.full_payment_paid_at = datetime.now()
        rental.pending_amount = 0
        rental.payment_status = 'paid'
        rental.deposit_paid = True
        rental.save()
        messages.success(request, f'Full payment marked as paid for {rental.booking_reference}')
    return redirect(f'{request.META.get("HTTP_REFERER", "admin_dashboard")}?section=payments')


@login_required
def admin_process_cancellation(request, rental_id):
    """Process cancellation with refund calculation"""
    try:
        if request.user.userprofile.role != 'admin':
            messages.error(request, 'Access denied.')
            return redirect('home')
    except:
        messages.error(request, 'Profile not found.')
        return redirect('home')
    
    rental = get_object_or_404(Rental, id=rental_id)
    cancellation_charge = rental.total_price * Decimal('0.10')
    refund_amount = rental.total_price - cancellation_charge
    Cancellation.objects.create(rental=rental, reason='Admin processed cancellation', refund_amount=refund_amount, refund_processed=False)
    rental.status = 'cancelled'
    rental.refund_amount = refund_amount
    rental.payment_status = 'partially_refunded'
    rental.save()
    messages.success(request, f'Cancellation processed for {rental.booking_reference}. Refund: Rs.{refund_amount} (10% charge: Rs.{cancellation_charge})')
    return redirect(f'{request.META.get("HTTP_REFERER", "admin_dashboard")}?section=refunds')


@login_required
def admin_process_refund(request, rental_id):
    """Process refund for cancelled booking"""
    try:
        if request.user.userprofile.role != 'admin':
            messages.error(request, 'Access denied.')
            return redirect('home')
    except:
        messages.error(request, 'Profile not found.')
        return redirect('home')
    
    rental = get_object_or_404(Rental, id=rental_id)
    rental.refund_processed = True
    rental.refund_processed_at = datetime.now()
    rental.payment_status = 'refunded'
    rental.save()
    try:
        cancellation = Cancellation.objects.get(rental=rental)
        cancellation.refund_processed = True
        cancellation.save()
    except Cancellation.DoesNotExist:
        pass
    messages.success(request, f'Refund of Rs.{rental.refund_amount} processed for {rental.booking_reference}')
    return redirect(f'{request.META.get("HTTP_REFERER", "admin_dashboard")}?section=refunds')


@login_required
def admin_respond_message(request, message_id):
    """Respond to contact message"""
    try:
        if request.user.userprofile.role != 'admin':
            messages.error(request, 'Access denied.')
            return redirect('home')
    except:
        messages.error(request, 'Profile not found.')
        return redirect('home')
    
    if request.method == 'POST':
        response = request.POST.get('response', '')
        message = get_object_or_404(ContactMessage, id=message_id)
        message.admin_response = response
        message.responded = True
        message.save()
        messages.success(request, 'Response sent successfully!')
    return redirect(f'{request.META.get("HTTP_REFERER", "admin_dashboard")}?section=contact')


@login_required
def admin_manage_coupon(request):
    """Create or update coupon"""
    try:
        if request.user.userprofile.role != 'admin':
            messages.error(request, 'Access denied.')
            return redirect('home')
    except:
        messages.error(request, 'Profile not found.')
        return redirect('home')
    
    if request.method == 'POST':
        coupon_id = request.POST.get('coupon_id')
        code = request.POST.get('code', '').upper()
        discount_type = request.POST.get('discount_type')
        discount_value = Decimal(request.POST.get('discount_value', 0))
        min_order_value = Decimal(request.POST.get('min_order_value', 0))
        max_discount = request.POST.get('max_discount')
        valid_from = request.POST.get('valid_from')
        valid_to = request.POST.get('valid_to')
        usage_limit = int(request.POST.get('usage_limit', 1))
        
        if coupon_id:
            coupon = get_object_or_404(Coupon, id=coupon_id)
            coupon.code = code
            coupon.discount_type = discount_type
            coupon.discount_value = discount_value
            coupon.min_order_value = min_order_value
            if max_discount:
                coupon.max_discount = Decimal(max_discount)
            coupon.valid_from = valid_from
            coupon.valid_to = valid_to
            coupon.usage_limit = usage_limit
            coupon.save()
            messages.success(request, f'Coupon {code} updated successfully!')
        else:
            Coupon.objects.create(code=code, discount_type=discount_type, discount_value=discount_value,
                min_order_value=min_order_value, max_discount=Decimal(max_discount) if max_discount else None,
                valid_from=valid_from, valid_to=valid_to, usage_limit=usage_limit, active=True)
            messages.success(request, f'Coupon {code} created successfully!')
    return redirect(f'{request.META.get("HTTP_REFERER", "admin_dashboard")}?section=offers')


@login_required
def admin_toggle_coupon(request, coupon_id):
    """Toggle coupon active status"""
    try:
        if request.user.userprofile.role != 'admin':
            messages.error(request, 'Access denied.')
            return redirect('home')
    except:
        messages.error(request, 'Profile not found.')
        return redirect('home')
    
    coupon = get_object_or_404(Coupon, id=coupon_id)
    coupon.active = not coupon.active
    coupon.save()
    status = 'activated' if coupon.active else 'deactivated'
    messages.success(request, f'Coupon {coupon.code} {status}!')
    return redirect(f'{request.META.get("HTTP_REFERER", "admin_dashboard")}?section=offers')

def subscription_plans(request):
    """Subscription and membership page"""
    plans = [
        {
            'name': 'Basic',
            'price': 499,
            'features': ['Priority booking', '10% discount', 'Free cancellation'],
        },
        {
            'name': 'Premium',
            'price': 999,
            'features': ['Priority booking', '20% discount', 'Free cancellation', 'Dedicated support', 'Free add-ons'],
        },
        {
            'name': 'Enterprise',
            'price': 1999,
            'features': ['Priority booking', '30% discount', 'Free cancellation', 'Dedicated support', 'Free add-ons', 'Corporate rates'],
        },
    ]
    return render(request, 'rentals/subscription.html', {'plans': plans})

@login_required
def booking_wizard_step1(request, car_id):
    """Step 1: Select dates and locations"""
    car = get_object_or_404(Car, id=car_id, available=True)

    if request.method == 'POST':
        start_date = request.POST.get('start_date')
        end_date = request.POST.get('end_date')
        pickup_location = request.POST.get('pickup_location')
        dropoff_location = request.POST.get('dropoff_location', '')

        try:
            start = datetime.strptime(start_date, '%Y-%m-%d').date()
            end = datetime.strptime(end_date, '%Y-%m-%d').date()
            if start >= end or start < date.today():
                messages.error(request, 'Invalid date selection.')
                return redirect('booking_wizard_step1', car_id=car_id)
        except:
            messages.error(request, 'Invalid date format.')
            return redirect('booking_wizard_step1', car_id=car_id)

        if not car.is_available():
            messages.error(request, 'Car is not available.')
            return redirect('car_detail', car_id=car_id)

        request.session['booking'] = {
            'car_id': car_id,
            'start_date': start_date,
            'end_date': end_date,
            'pickup_location': pickup_location,
            'dropoff_location': dropoff_location,
        }
        return redirect('booking_wizard_step2')

    context = {'car': car}
    return render(request, 'rentals/booking_step1.html', context)

@login_required
def booking_wizard_step2(request):
    """Step 2: Choose add-ons"""
    booking_data = request.session.get('booking')
    if not booking_data:
        messages.error(request, 'Booking session expired.')
        return redirect('home')

    car = get_object_or_404(Car, id=booking_data['car_id'])
    add_ons = AddOnService.objects.filter(active=True)

    if request.method == 'POST':
        selected_addons = request.POST.getlist('addons')
        special_requests = request.POST.get('special_requests', '')

        booking_data['addons'] = selected_addons
        booking_data['special_requests'] = special_requests
        request.session['booking'] = booking_data
        return redirect('booking_wizard_step3')

    context = {
        'car': car,
        'add_ons': add_ons,
        'booking_data': booking_data,
    }
    return render(request, 'rentals/booking_step2.html', context)

@login_required
def booking_wizard_step3(request):
    """Step 3: Payment and confirmation"""
    booking_data = request.session.get('booking')
    if not booking_data:
        messages.error(request, 'Booking session expired.')
        return redirect('home')

    car = get_object_or_404(Car, id=booking_data['car_id'])
    add_ons = AddOnService.objects.filter(id__in=booking_data.get('addons', []))

    start = datetime.strptime(booking_data['start_date'], '%Y-%m-%d').date()
    end = datetime.strptime(booking_data['end_date'], '%Y-%m-%d').date()
    days = (end - start).days + 1

    base_price = car.get_current_price() * days
    add_on_total = sum(addon.price for addon in add_ons)
    tax = (base_price + add_on_total) * Decimal('0.18')
    total = base_price + add_on_total + tax + car.security_deposit

    if request.method == 'POST':
        rental = Rental.objects.create(
            user=request.user,
            car=car,
            start_date=start,
            end_date=end,
            pickup_location=booking_data['pickup_location'],
            dropoff_location=booking_data['dropoff_location'],
            total_days=days,
            base_price=base_price,
            tax_amount=tax,
            total_price=total,
            security_deposit=car.security_deposit,
            add_ons=list(add_ons.values('name', 'price')),
            special_requests=booking_data.get('special_requests', ''),
        )

        del request.session['booking']

        messages.success(request, f'Booking confirmed! Reference: {rental.booking_reference}')
        return redirect('booking_confirmation', booking_ref=rental.booking_reference)

    context = {
        'car': car,
        'add_ons': add_ons,
        'booking_data': booking_data,
        'days': days,
        'base_price': base_price,
        'add_on_total': add_on_total,
        'tax': tax,
        'total': total,
    }
    return render(request, 'rentals/booking_step3.html', context)

def booking_confirmation(request, booking_ref):
    """Booking confirmation page"""
    rental = get_object_or_404(Rental, booking_reference=booking_ref, user=request.user)
    context = {'rental': rental}
    return render(request, 'rentals/booking_confirmation.html', context)

@login_required
def user_dashboard(request):
    """User dashboard"""
    profile, created = UserProfile.objects.get_or_create(user=request.user)
    
    recent_rentals = Rental.objects.filter(user=request.user).order_by('-created_at')[:5]

    upcoming_rentals = Rental.objects.filter(
        user=request.user,
        start_date__gte=date.today(),
        status__in=['confirmed', 'active']
    ).order_by('start_date')

    wallet_balance = profile.wallet_balance
    loyalty_points = profile.loyalty_points

    context = {
        'recent_rentals': recent_rentals,
        'upcoming_rentals': upcoming_rentals,
        'wallet_balance': wallet_balance,
        'loyalty_points': loyalty_points,
    }
    return render(request, 'rentals/user_dashboard.html', context)

@login_required
def cancel_booking(request, booking_ref):
    """Cancel booking"""
    rental = get_object_or_404(Rental, booking_reference=booking_ref, user=request.user)

    if rental.status not in ['pending', 'confirmed']:
        messages.error(request, 'Cannot cancel this booking.')
        return redirect('rentals:rentals')

    if request.method == 'POST':
        reason = request.POST.get('reason')
        
        refund_amount = 0
        if rental.payment_status == 'paid' and rental.deposit_paid:
            cancellation_charge = rental.total_price * Decimal('0.10')
            refund_amount = rental.total_price - cancellation_charge
        
        Cancellation.objects.create(rental=rental, reason=reason, refund_amount=refund_amount, refund_processed=False)
        rental.status = 'cancelled'
        rental.refund_amount = refund_amount
        if refund_amount > 0:
            rental.payment_status = 'partially_refunded'
        else:
            rental.payment_status = 'cancelled'
        rental.save()
        messages.success(request, 'Booking cancelled successfully.')
        return redirect('rentals:rentals')

    context = {'rental': rental}
    return render(request, 'rentals/cancel_booking.html', context)

@login_required
def submit_review(request, booking_ref):
    """Submit review for completed rental"""
    rental = get_object_or_404(Rental, booking_reference=booking_ref, user=request.user, status='completed')

    if Review.objects.filter(rental=rental).exists():
        messages.error(request, 'Review already submitted.')
        return redirect('dashboard')

    if request.method == 'POST':
        rating = request.POST.get('rating')
        title = request.POST.get('title')
        comment = request.POST.get('comment')

        Review.objects.create(
            rental=rental,
            user=request.user,
            car=rental.car,
            rating=rating,
            title=title,
            comment=comment,
        )

        car_reviews = Review.objects.filter(car=rental.car)
        avg_rating = car_reviews.aggregate(Avg('rating'))['rating__avg']
        rental.car.rating = avg_rating
        rental.car.review_count = car_reviews.count()
        rental.car.save()

        messages.success(request, 'Review submitted successfully.')
        return redirect('dashboard')

    context = {'rental': rental}
    return render(request, 'rentals/submit_review.html', context)

def offers(request):
    """Offers and coupons page"""
    active_coupons = Coupon.objects.filter(active=True, valid_to__gte=date.today())
    context = {'coupons': active_coupons}
    return render(request, 'rentals/offers.html', context)

def blog_list(request):
    """Blog listing page"""
    posts = BlogPost.objects.filter(published=True).order_by('-published_at')
    paginator = Paginator(posts, 10)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    context = {'page_obj': page_obj}
    return render(request, 'rentals/blog_list.html', context)

def blog_detail(request, slug):
    """Blog detail page"""
    post = get_object_or_404(BlogPost, slug=slug, published=True)
    context = {'post': post}
    return render(request, 'rentals/blog_detail.html', context)

def payment_info(request):
    """Payment information page with user payment records"""
    if not request.user.is_authenticated:
        messages.error(request, 'Please login to view your payment information.')
        return redirect('login')
    
    user_rentals = Rental.objects.filter(user=request.user).select_related('car')
    
    pending_payments = user_rentals.filter(
        deposit_paid=True,
        full_payment_paid=False,
        status__in=['confirmed', 'pending']
    ).order_by('-created_at')
    
    total_pending_amount = sum(rental.pending_amount for rental in pending_payments)
    
    pending_refunds = user_rentals.filter(
        status='cancelled',
        deposit_paid=True,
        refund_amount__gt=0,
        refund_processed=False
    ).order_by('-created_at')
    
    total_pending_refund = sum(rental.refund_amount for rental in pending_refunds)
    
    deposit_payments = user_rentals.filter(
        deposit_paid=True
    ).order_by('-deposit_paid_at')
    
    refund_history = user_rentals.filter(
        status='cancelled',
        refund_amount__gt=0,
        refund_processed=True
    ).order_by('-refund_processed_at')
    
    total_deposits_paid = sum(rental.deposit_amount for rental in deposit_payments)
    total_refunds_received = sum(rental.refund_amount for rental in refund_history)
    
    completed_payments = user_rentals.filter(
        full_payment_paid=True,
        status__in=['completed', 'active', 'confirmed']
    ).order_by('-created_at')
    
    total_completed = sum(rental.total_price for rental in completed_payments)
    
    confirmed_payments = PaymentConfirmation.objects.filter(
        rental__user=request.user,
        is_confirmed=True
    ).select_related('rental', 'rental__car').order_by('-confirmed_at')
    
    context = {
        'pending_payments': pending_payments,
        'total_pending_amount': total_pending_amount,
        'pending_refunds': pending_refunds,
        'total_pending_refund': total_pending_refund,
        'deposit_payments': deposit_payments,
        'total_deposits_paid': total_deposits_paid,
        'refund_history': refund_history,
        'total_refunds_received': total_refunds_received,
        'completed_payments': completed_payments,
        'total_completed': total_completed,
        'confirmed_payments': confirmed_payments,
        'full_paid_rentals': completed_payments,
        'total_full_paid_amount': total_completed,
    }
    return render(request, 'rentals/payment_info.html', context)


@login_required
def pay_remaining_amount(request, booking_ref):
    """Pay remaining amount for a booking after deposit"""
    rental = get_object_or_404(Rental, booking_reference=booking_ref, user=request.user)
    
    if not rental.deposit_paid or rental.full_payment_paid:
        messages.error(request, 'This booking does not require remaining payment.')
        return redirect('rentals:payment_info')
    
    if rental.status == 'cancelled':
        messages.error(request, 'Cannot make payment for cancelled booking.')
        return redirect('rentals:payment_info')
    
    if request.method == 'POST':
        payment_method = request.POST.get('payment_method', 'card')
        remaining_amount = rental.pending_amount
        
        rental.full_payment_paid = True
        rental.full_payment_paid_at = datetime.now()
        rental.pending_amount = 0
        rental.payment_status = 'paid'
        rental.payment_method = payment_method
        rental.save()
        
        transaction = PaymentTransaction.objects.create(
            rental=rental,
            transaction_type='remaining',
            amount=remaining_amount,
            status='pending',
            transaction_id=f"REM{rental.booking_reference}{datetime.now().strftime('%Y%m%d%H%M%S')}",
            payment_method=payment_method,
            notes="Remaining payment made by user"
        )
        
        confirmation = PaymentConfirmation.objects.create(
            rental=rental,
            confirmation_type='remaining',
            amount=remaining_amount,
            is_confirmed=True,
            confirmed_by=request.user,
            confirmed_at=datetime.now(),
            confirmation_notes='Auto-confirmed when user paid remaining amount',
            payment_proof=f"Transaction ID: {transaction.transaction_id}"
        )
        
        messages.success(request, f'Payment successful! Full payment completed for {rental.booking_reference}. Admin will verify and confirm shortly.')
        return redirect('rentals:payment_info')
    
    context = {'rental': rental}
    return render(request, 'rentals/pay_remaining.html', context)


def contact(request):
    """Contact and support page"""
    if request.method == 'POST':
        name = request.POST.get('name', '')
        email = request.POST.get('email', '')
        phone = request.POST.get('phone', '')
        subject = request.POST.get('subject', '')
        message = request.POST.get('message', '')
        rating = request.POST.get('rating')
        feedback = request.POST.get('feedback', '')

        ContactMessage.objects.create(
            name=name,
            email=email,
            phone=phone,
            subject=subject,
            message=message,
            rating=rating if rating else None,
            feedback=feedback,
        )
        messages.success(request, 'Message sent successfully. We will get back to you soon.')
        return redirect('contact')

    return render(request, 'rentals/contact.html')

def compare_cars(request):
    """Compare cars page"""
    car_ids = request.GET.getlist('cars')
    cars = Car.objects.filter(id__in=car_ids)[:4]
    context = {'cars': cars}
    return render(request, 'rentals/compare_cars.html', context)

def corporate_booking(request):
    """Corporate booking page"""
    if request.method == 'POST':
        company_name = request.POST.get('company_name')
        contact_person = request.POST.get('contact_person')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        number_of_cars = request.POST.get('number_of_cars')
        start_date = request.POST.get('start_date')
        end_date = request.POST.get('end_date')
        special_requirements = request.POST.get('special_requirements', '')

        CorporateBooking.objects.create(
            company_name=company_name,
            contact_person=contact_person,
            email=email,
            phone=phone,
            number_of_cars=number_of_cars,
            start_date=start_date,
            end_date=end_date,
            special_requirements=special_requirements,
        )
        messages.success(request, 'Corporate booking request submitted successfully. We will get back to you soon.')
        return redirect('corporate_booking')

    return render(request, 'rentals/corporate_booking.html')

def rentals_list(request):
    """List user's rentals - includes all rentals including cancelled"""
    rentals = Rental.objects.filter(user=request.user).order_by('-created_at')
    context = {'rentals': rentals}
    return render(request, 'rentals/rentals.html', context)


@login_required
def admin_payment_section(request):
    """Admin payment management section - shows all payment records"""
    try:
        if request.user.userprofile.role != 'admin':
            messages.error(request, 'Access denied.')
            return redirect('home')
    except:
        messages.error(request, 'Profile not found.')
        return redirect('home')
    
    pending_full_payments = Rental.objects.filter(
        deposit_paid=True,
        full_payment_paid=False,
        pending_amount__gt=0,
        status__in=['pending', 'confirmed']
    ).select_related('user', 'car').order_by('-created_at')
    
    total_pending_full = sum(r.pending_amount for r in pending_full_payments)
    
    completed_payments = Rental.objects.filter(
        full_payment_paid=True
    ).select_related('user', 'car').order_by('-full_payment_paid_at')
    
    total_completed = sum(r.total_price for r in completed_payments)
    
    pending_refunds = Rental.objects.filter(
        status='cancelled',
        deposit_paid=True,
        refund_amount__gt=0,
        refund_processed=False
    ).select_related('user', 'car').order_by('-created_at')
    
    total_pending_refund = sum(r.refund_amount for r in pending_refunds)
    
    processed_refunds = Rental.objects.filter(
        status='cancelled',
        refund_amount__gt=0,
        refund_processed=True
    ).select_related('user', 'car').order_by('-refund_processed_at')
    
    total_processed_refund = sum(r.refund_amount for r in processed_refunds)
    
    payment_confirmations = PaymentConfirmation.objects.select_related(
        'rental', 'rental__user', 'rental__car', 'confirmed_by'
    ).order_by('-created_at')
    
    deposit_payments = Rental.objects.filter(
        deposit_paid=True
    ).select_related('user', 'car').order_by('-deposit_paid_at')
    
    context = {
        'pending_full_payments': pending_full_payments,
        'total_pending_full': total_pending_full,
        'completed_payments': completed_payments,
        'total_completed': total_completed,
        'pending_refunds': pending_refunds,
        'total_pending_refund': total_pending_refund,
        'processed_refunds': processed_refunds,
        'total_processed_refund': total_processed_refund,
        'payment_confirmations': payment_confirmations,
        'deposit_payments': deposit_payments,
    }
    
    return render(request, 'rentals/admin_payment_section.html', context)

@login_required
def payment_page(request, car_id):
    """Payment page for car rental"""
    car = get_object_or_404(Car, id=car_id)
    
    if request.method == 'POST':
        start_date = request.POST.get('start_date')
        end_date = request.POST.get('end_date')
        pickup_location = request.POST.get('pickup_location', '')
        dropoff_location = request.POST.get('dropoff_location', '')
        
        if start_date and end_date:
            try:
                start = datetime.strptime(start_date, '%Y-%m-%d').date()
                end = datetime.strptime(end_date, '%Y-%m-%d').date()
                today = date.today()
                
                if start < today:
                    messages.error(request, 'Pickup date cannot be in the past. Please select a valid future date.')
                    return redirect('rent_car', car_id=car_id)
                
                if end < today:
                    messages.error(request, 'Return date cannot be in the past. Please select a valid future date.')
                    return redirect('rent_car', car_id=car_id)
                
                if start >= end:
                    messages.error(request, 'Return date must be after pickup date.')
                    return redirect('rent_car', car_id=car_id)
                
                conflicting_rentals = Rental.objects.filter(
                    car=car,
                    status__in=['pending', 'confirmed', 'active'],
                    start_date__lte=end,
                    end_date__gte=start
                )
                
                if conflicting_rentals.exists():
                    messages.error(request, f'This car is not available for the selected dates ({start_date} to {end_date}). Please choose different dates.')
                    return redirect('rent_car', car_id=car_id)
            except ValueError:
                messages.error(request, 'Invalid date format.')
                return redirect('rent_car', car_id=car_id)
        
        add_ons = []
        addon_prices = {
            'additional_driver': 300,
            'insurance': 200,
            'gps': 100,
            'child_seat': 150,
            'wifi': 100,
            'fastag': 50
        }
        
        for addon_name, addon_price in addon_prices.items():
            if request.POST.get(addon_name) == 'yes':
                add_ons.append({
                    'name': addon_name.replace('_', ' ').title(),
                    'price': addon_price
                })
        
        promo_code = request.POST.get('promo_code', '').upper()
        
        try:
            start = datetime.strptime(start_date, '%Y-%m-%d').date()
            end = datetime.strptime(end_date, '%Y-%m-%d').date()
            days = (end - start).days + 1
            if days < 1:
                days = 1
        except:
            days = 1
        
        daily_rate = car.price_per_day
        if start_date:
            try:
                start = datetime.strptime(start_date, '%Y-%m-%d').date()
                day_of_week = start.weekday()
                if day_of_week in [4, 5, 6] and car.weekend_price:
                    daily_rate = car.weekend_price
                if car.festival_price:
                    daily_rate = min(daily_rate, car.festival_price)
            except:
                pass
        
        rental_cost = daily_rate * days
        addons_cost = sum(addon['price'] * days for addon in add_ons)
        
        discount_amount = 0
        promo_codes = {
            'NEWUSER': {'discount': 10, 'type': 'percentage'},
            'FIRST50': {'discount': 50, 'type': 'fixed'},
            'DWARKADHISH': {'discount': 15, 'type': 'percentage'},
            'CAR2024': {'discount': 20, 'type': 'percentage'}
        }
        
        if promo_code in promo_codes:
            promo = promo_codes[promo_code]
            if promo['type'] == 'percentage':
                discount_amount = (rental_cost * promo['discount']) / 100
            else:
                discount_amount = promo['discount']
        
        is_first_booking = False
        try:
            profile, _ = UserProfile.objects.get_or_create(user=request.user)
            is_first_booking = profile.is_first_booking
            
            if is_first_booking:
                first_booking_discount = (rental_cost * Decimal('0.10'))
                discount_amount += first_booking_discount
        except Exception:
            pass
        
        subtotal = rental_cost + addons_cost - discount_amount
        gst_rate = 0.18
        gst_amount = subtotal * Decimal(str(gst_rate))
        security_deposit = car.security_deposit or Decimal('5000')
        total_amount = subtotal + gst_amount + security_deposit
        
        request.session['payment_data'] = {
            'car_id': car_id,
            'start_date': start_date,
            'end_date': end_date,
            'pickup_location': pickup_location,
            'dropoff_location': dropoff_location,
            'days': days,
            'daily_rate': float(daily_rate),
            'rental_cost': float(rental_cost),
            'addons': add_ons,
            'addons_cost': float(addons_cost),
            'promo_code': promo_code,
            'discount_amount': float(discount_amount),
            'gst_amount': float(gst_amount),
            'security_deposit': float(security_deposit),
            'total_amount': float(total_amount),
            'deposit_amount': float(total_amount * Decimal('0.10')),
            'remaining_amount': float(total_amount - (total_amount * Decimal('0.10'))),
            'payment_type': 'deposit',
            'is_first_booking': is_first_booking,
        }
        
        deposit_amount_val = total_amount * Decimal('0.10')
        remaining_amount_val = total_amount - deposit_amount_val
        
        context = {
            'car': car,
            'start_date': start_date,
            'end_date': end_date,
            'pickup_location': pickup_location,
            'dropoff_location': dropoff_location,
            'days': days,
            'daily_rate': daily_rate,
            'rental_cost': rental_cost,
            'add_ons': add_ons,
            'addons_cost': addons_cost,
            'promo_code': promo_code,
            'discount_amount': discount_amount,
            'gst_amount': gst_amount,
            'security_deposit': security_deposit,
            'total_amount': total_amount,
            'deposit_amount': deposit_amount_val,
            'remaining_amount': remaining_amount_val,
            'is_first_booking': is_first_booking,
        }
        return render(request, 'cars/payment.html', context)
    
    return redirect('rent_car', car_id=car_id)

@login_required
def process_payment(request):
    """Process payment and create rental"""
    if request.method != 'POST':
        return redirect('home')
    
    payment_data = request.session.get('payment_data')
    if not payment_data:
        messages.error(request, 'Payment session expired. Please try again.')
        return redirect('home')
    
    payment_method = request.POST.get('payment_method', 'card')
    payment_type = request.POST.get('payment_type', 'deposit')
    
    car = get_object_or_404(Car, id=payment_data['car_id'])
    
    start = datetime.strptime(payment_data['start_date'], '%Y-%m-%d').date()
    end = datetime.strptime(payment_data['end_date'], '%Y-%m-%d').date()
    
    conflicting_rentals = Rental.objects.filter(
        car=car,
        status__in=['pending', 'confirmed', 'active'],
        start_date__lte=end,
        end_date__gte=start
    )
    
    if conflicting_rentals.exists():
        if 'payment_data' in request.session:
            del request.session['payment_data']
        messages.error(request, 'Sorry! This car has just been booked for the selected dates by another customer. Please choose different dates or a different car.')
        return redirect('car_detail', car_id=car.id)
    
    total_amount = Decimal(str(payment_data['total_amount']))
    deposit_amount = total_amount * Decimal('0.10')
    remaining_amount = total_amount - deposit_amount
    
    if payment_method == 'cash':
        rental = Rental.objects.create(
            user=request.user,
            car=car,
            start_date=start,
            end_date=end,
            pickup_location=payment_data['pickup_location'],
            dropoff_location=payment_data['dropoff_location'],
            total_days=payment_data['days'],
            base_price=payment_data['rental_cost'],
            discount_amount=payment_data['discount_amount'],
            tax_amount=payment_data['gst_amount'],
            total_price=payment_data['total_amount'],
            security_deposit=payment_data['security_deposit'],
            add_ons=payment_data['addons'],
            coupon_used=payment_data['promo_code'],
            deposit_amount=0,
            deposit_paid=False,
            full_payment_paid=False,
            pending_amount=total_amount,
            status='pending',
            payment_status='pending',
            payment_method=payment_method,
        )
        
        del request.session['payment_data']
        
        messages.success(request, f'Booking confirmed with Cash at Pickup! Please pay ₹{total_amount} at the time of vehicle pickup. Reference: {rental.booking_reference}')
        return redirect('rentals:booking_confirmation', booking_ref=rental.booking_reference)
    
    if payment_type == 'full':
        rental = Rental.objects.create(
            user=request.user,
            car=car,
            start_date=start,
            end_date=end,
            pickup_location=payment_data['pickup_location'],
            dropoff_location=payment_data['dropoff_location'],
            total_days=payment_data['days'],
            base_price=payment_data['rental_cost'],
            discount_amount=payment_data['discount_amount'],
            tax_amount=payment_data['gst_amount'],
            total_price=payment_data['total_amount'],
            security_deposit=payment_data['security_deposit'],
            add_ons=payment_data['addons'],
            coupon_used=payment_data['promo_code'],
            deposit_amount=deposit_amount,
            deposit_paid=True,
            deposit_paid_at=datetime.now(),
            full_payment_paid=True,
            full_payment_paid_at=datetime.now(),
            pending_amount=0,
            status='confirmed',
            payment_status='paid',
        )
    else:
        rental = Rental.objects.create(
            user=request.user,
            car=car,
            start_date=start,
            end_date=end,
            pickup_location=payment_data['pickup_location'],
            dropoff_location=payment_data['dropoff_location'],
            total_days=payment_data['days'],
            base_price=payment_data['rental_cost'],
            discount_amount=payment_data['discount_amount'],
            tax_amount=payment_data['gst_amount'],
            total_price=payment_data['total_amount'],
            security_deposit=payment_data['security_deposit'],
            add_ons=payment_data['addons'],
            coupon_used=payment_data['promo_code'],
            deposit_amount=deposit_amount,
            deposit_paid=True,
            deposit_paid_at=datetime.now(),
            full_payment_paid=False,
            pending_amount=remaining_amount,
            status='confirmed',
            payment_status='paid',
        )
    
    del request.session['payment_data']
    
    try:
        profile = UserProfile.objects.get(user=request.user)
        if profile.is_first_booking:
            profile.is_first_booking = False
            profile.save()
    except UserProfile.DoesNotExist:
        pass
    
    if payment_type == 'full':
        PaymentConfirmation.objects.create(
            rental=rental,
            confirmation_type='deposit',
            amount=deposit_amount,
            is_confirmed=True,
            confirmed_by=request.user,
            confirmed_at=datetime.now(),
            confirmation_notes='Auto-confirmed with full payment',
            payment_proof=f"Full payment via {payment_method}"
        )
        PaymentConfirmation.objects.create(
            rental=rental,
            confirmation_type='full',
            amount=total_amount,
            is_confirmed=True,
            confirmed_by=request.user,
            confirmed_at=datetime.now(),
            confirmation_notes='Full payment confirmed',
            payment_proof=f"Full payment via {payment_method}"
        )
    else:
        PaymentConfirmation.objects.create(
            rental=rental,
            confirmation_type='deposit',
            amount=deposit_amount,
            is_confirmed=True,
            confirmed_by=request.user,
            confirmed_at=datetime.now(),
            confirmation_notes='Deposit payment confirmed',
            payment_proof=f"Deposit via {payment_method}"
        )
    
    messages.success(request, f'Payment successful! Booking confirmed. Reference: {rental.booking_reference}')
    return redirect('rentals:booking_confirmation', booking_ref=rental.booking_reference)
