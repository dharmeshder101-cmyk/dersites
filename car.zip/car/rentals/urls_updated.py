from django.urls import path
from . import views

app_name = 'rentals'

urlpatterns = [
    # Booking wizard
    path('book/<int:car_id>/', views.booking_wizard_step1, name='booking_wizard_step1'),
    path('book/step2/', views.booking_wizard_step2, name='booking_wizard_step2'),
    path('book/step3/', views.booking_wizard_step3, name='booking_wizard_step3'),
    path('booking/<str:booking_ref>/', views.booking_confirmation, name='booking_confirmation'),
    
    # Payment pages
    path('payment/<int:car_id>/', views.payment_page, name='payment_page'),
    path('process-payment/', views.process_payment, name='process_payment'),

    # Booking management
    path('', views.rentals_list, name='rentals'),
    path('cancel/<str:booking_ref>/', views.cancel_booking, name='cancel_booking'),
    path('review/<str:booking_ref>/', views.submit_review, name='submit_review'),

    # Contact page
    path('contact/', views.contact, name='contact'),
    
    # Admin management URLs
    path('admin/rental/<int:rental_id>/<str:action>/', views.admin_rental_action, name='admin_rental_action'),
    path('admin/payment/<int:rental_id>/<str:action>/', views.admin_payment_action, name='admin_payment_action'),
    path('admin/cancellation/<int:rental_id>/process/', views.admin_process_cancellation, name='admin_process_cancellation'),
    path('admin/refund/<int:rental_id>/process/', views.admin_process_refund, name='admin_process_refund'),
    path('admin/message/<int:message_id>/respond/', views.admin_respond_message, name='admin_respond_message'),
    path('admin/coupon/manage/', views.admin_manage_coupon, name='admin_manage_coupon'),
    path('admin/coupon/<int:coupon_id>/toggle/', views.admin_toggle_coupon, name='admin_toggle_coupon'),
]
