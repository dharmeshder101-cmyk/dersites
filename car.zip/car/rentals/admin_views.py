from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q, Avg, Sum, Count
from django.contrib.auth.models import User
from django.utils import timezone
from django.http import JsonResponse
from datetime import datetime, date, timedelta
from decimal import Decimal
from .models import Rental, Review, AddOnService, Cancellation, CorporateBooking, BlogPost, ContactMessage
from cars.models import Car
from payments.models import Payment, Coupon, Refund, PaymentTransaction, PaymentConfirmation
from accounts.models import UserProfile


@login_required
def admin_dashboard(request):
    """Main admin dashboard view"""
    # Check if user is admin
    try:
        if request.user.userprofile.role != 'admin':
            messages.error(request, 'Access denied. Admin only.')
            return redirect('home')
    except:
        messages.error(request, 'Profile not found.')
        return redirect('home')
    
    # Get filter parameters
    filter_type = request.GET.get('filter', 'all')
    payment_filter = request.GET.get('payment_filter', 'all')
    refund_filter = request.GET.get('refund_filter', 'pending')
    message_filter = request.GET.get('message_filter', 'all')
    user_filter = request.GET.get('user_filter', 'all')
    car_filter = request.GET.get('car_filter', 'all')
    current_section = request.GET.get('section', 'Dashboard Overview')
    
    # Base queries
    today = date.today()
    
    # Overview statistics
    total_rentals = Rental.objects.count()
    pending_rentals = Rental.objects.filter(status='pending')
    confirmed_rentals = Rental.objects.filter(status='confirmed')
    active_rentals = Rental.objects.filter(status='active')
    completed_rentals = Rental.objects.filter(status='completed')
    
    # Revenue calculations
    total_revenue = Rental.objects.filter(
        status__in=['completed', 'active', 'confirmed']
    ).aggregate(Sum('total_price'))['total_price__sum'] or 0
    
    # Deposit calculations
    total_deposits = Rental.objects.filter(
        deposit_paid=True
    ).aggregate(Sum('deposit_amount'))['deposit_amount__sum'] or 0
    
    # User statistics
    total_users = UserProfile.objects.count()
    
    # Car statistics
    total_cars = Car.objects.count()
    
    # Pending cancellations
    pending_cancellations = Rental.objects.filter(status='cancelled')
    
    # Recent rentals
    recent_rentals = Rental.objects.select_related('car', 'user').order_by('-created_at')[:10]
    
    # ============ RENTALS SECTION ============
    if filter_type == 'all' or not filter_type:
        all_rentals = Rental.objects.select_related('car', 'user').order_by('-created_at')
    else:
        all_rentals = Rental.objects.filter(status=filter_type).select_related('car', 'user').order_by('-created_at')
    
    # ============ PAYMENTS SECTION ============
    if payment_filter == 'all':
        payment_rentals = Rental.objects.select_related('car', 'user').order_by('-created_at')
    elif payment_filter == 'deposit':
        payment_rentals = Rental.objects.filter(deposit_paid=True).select_related('car', 'user')
    elif payment_filter == 'full':
        payment_rentals = Rental.objects.filter(full_payment_paid=True).select_related('car', 'user')
    elif payment_filter == 'pending':
        payment_rentals = Rental.objects.filter(
            Q(deposit_paid=False) | Q(full_payment_paid=False)
        ).select_related('car', 'user')
    else:
        payment_rentals = Rental.objects.select_related('car', 'user').order_by('-created_at')
    
    # Payment stats
    total_paid = Rental.objects.filter(
        payment_status='paid'
    ).aggregate(Sum('total_price'))['total_price__sum'] or 0
    
    total_full_payments = Rental.objects.filter(
        full_payment_paid=True
    ).aggregate(Sum('total_price'))['total_price__sum'] or 0
    
    total_pending_payments = Rental.objects.filter(
        payment_status='pending'
    ).aggregate(Sum('total_price'))['total_price__sum'] or 0
    
    # ============ PENDING & CONFIRMED PAYMENTS (NEW) ============
    # Get pending payments (PaymentTransaction with status='pending')
    pending_payment_transactions = PaymentTransaction.objects.filter(
        status='pending'
    ).select_related('rental', 'rental__car', 'rental__user').order_by('-created_at')
    
    # Get confirmed payments (PaymentTransaction with status='confirmed' or 'verified')
    confirmed_payment_transactions = PaymentTransaction.objects.filter(
        status__in=['confirmed', 'verified']
    ).select_related('rental', 'rental__car', 'rental__user').order_by('-created_at')
    
    # Get pending payment confirmations (PaymentConfirmation with is_confirmed=False)
    pending_payment_confirmations = PaymentConfirmation.objects.filter(
        is_confirmed=False
    ).select_related('rental', 'rental__car', 'rental__user').order_by('-created_at')
    
    # Get confirmed payment confirmations (PaymentConfirmation with is_confirmed=True)
    confirmed_payment_confirmations = PaymentConfirmation.objects.filter(
        is_confirmed=True
    ).select_related('rental', 'rental__car', 'rental__user').order_by('-confirmed_at')
    
    # Calculate totals for pending and confirmed
    total_pending_amount = pending_payment_transactions.aggregate(Sum('amount'))['amount__sum'] or 0
    total_confirmed_amount = confirmed_payment_transactions.aggregate(Sum('amount'))['amount__sum'] or 0
    
    # ============ REFUND & CANCELLATION SECTION ============
    if refund_filter == 'pending':
        cancellation_rentals = Rental.objects.filter(status='cancelled').select_related('car', 'user')
    elif refund_filter == 'processed':
        cancellation_rentals = Rental.objects.filter(
            status='cancelled',
            refund_processed=True
        ).select_related('car', 'user')
    else:
        cancellation_rentals = Rental.objects.filter(status='cancelled').select_related('car', 'user')
    
    completed_cancellations = Rental.objects.filter(
        status='cancelled',
        refund_processed=True
    )
    
    total_refunds_processed = completed_cancellations.aggregate(
        Sum('refund_amount')
    )['refund_amount__sum'] or 0
    
    total_cancellation_charges = total_revenue - total_refunds_processed
    
    # ============ CONTACT & FEEDBACK SECTION ============
    if message_filter == 'unread':
        contact_messages = ContactMessage.objects.filter(responded=False).order_by('-created_at')
    elif message_filter == 'responded':
        contact_messages = ContactMessage.objects.filter(responded=True).order_by('-created_at')
    elif message_filter == 'feedback':
        contact_messages = ContactMessage.objects.filter(
            Q(rating__isnull=False) | Q(feedback__isnull=False)
        ).order_by('-created_at')
    else:
        contact_messages = ContactMessage.objects.all().order_by('-created_at')
    
    total_messages = ContactMessage.objects.count()
    unread_messages = ContactMessage.objects.filter(responded=False)
    total_feedbacks = ContactMessage.objects.filter(
        Q(rating__isnull=False) | Q(feedback__isnull=False)
    ).count()
    
    avg_rating = ContactMessage.objects.filter(
        rating__isnull=False
    ).aggregate(Avg('rating'))['rating__avg'] or 0
    
    # ============ OFFERS SECTION ============
    coupons = Coupon.objects.all().order_by('-created_at')
    
    # ============ USERS SECTION ============
    if user_filter == 'all':
        all_users = UserProfile.objects.select_related('user').order_by('-user__date_joined')
    else:
        all_users = UserProfile.objects.filter(
            role=user_filter
        ).select_related('user').order_by('-user__date_joined')
    
    # ============ CARS SECTION ============
    if car_filter == 'available':
        all_cars = Car.objects.filter(available=True).order_by('-created_at')
    elif car_filter == 'rented':
        all_cars = Car.objects.filter(available=False).order_by('-created_at')
    else:
        all_cars = Car.objects.all().order_by('-created_at')
    
    # ============ REPORTS SECTION ============
    # Monthly stats
    monthly_stats = []
    for i in range(6):
        month_start = today.replace(day=1) - timedelta(days=i*30)
        month_end = month_start + timedelta(days=30)
        
        month_data = Rental.objects.filter(
            created_at__gte=month_start,
            created_at__lt=month_end
        ).aggregate(
            count=Count('id'),
            revenue=Sum('total_price'),
            deposits=Sum('deposit_amount')
        )
        
        month_refunds = Rental.objects.filter(
            status='cancelled',
            created_at__gte=month_start,
            created_at__lt=month_end
        ).aggregate(Sum('refund_amount'))['refund_amount__sum'] or 0
        
        monthly_stats.append({
            'month': month_start,
            'count': month_data['count'] or 0,
            'revenue': month_data['revenue'] or 0,
            'deposits': month_data['deposits'] or 0,
            'refunds': month_refunds
        })
    
    monthly_stats.reverse()
    
    # Report stats
    avg_booking_value = Rental.objects.aggregate(
        Avg('total_price')
    )['total_price__avg'] or 0
    
    avg_rental_days = Rental.objects.aggregate(
        Avg('total_days')
    )['total_days__avg'] or 0
    
    context = {
        # Section names
        'current_section': current_section,
        
        # Overview stats
        'total_rentals': total_rentals,
        'pending_rentals': pending_rentals,
        'confirmed_rentals': confirmed_rentals,
        'total_revenue': total_revenue,
        'total_users': total_users,
        'total_cars': total_cars,
        'total_deposits': total_deposits,
        'pending_cancellations': pending_cancellations,
        'recent_rentals': recent_rentals,
        
        # Rentals
        'all_rentals': all_rentals,
        'filter': filter_type,
        
        # Payments
        'payment_rentals': payment_rentals,
        'payment_filter': payment_filter,
        'total_paid': total_paid,
        'total_full_payments': total_full_payments,
        'total_pending_payments': total_pending_payments,
        
        # NEW: Pending and Confirmed Payments
        'pending_payment_transactions': pending_payment_transactions,
        'confirmed_payment_transactions': confirmed_payment_transactions,
        'pending_payment_confirmations': pending_payment_confirmations,
        'confirmed_payment_confirmations': confirmed_payment_confirmations,
        'total_pending_amount': total_pending_amount,
        'total_confirmed_amount': total_confirmed_amount,
        
        # Refunds
        'cancellation_rentals': cancellation_rentals,
        'refund_filter': refund_filter,
        'completed_cancellations': completed_cancellations,
        'total_refunds_processed': total_refunds_processed,
        'total_cancellation_charges': total_cancellation_charges,
        
        # Contact
        'contact_messages': contact_messages,
        'message_filter': message_filter,
        'total_messages': total_messages,
        'unread_messages': unread_messages,
        'total_feedbacks': total_feedbacks,
        'avg_rating': avg_rating,
        
        # Offers
        'coupons': coupons,
        'today': today,
        
        # Users
        'all_users': all_users,
        'user_filter': user_filter,
        
        # Cars
        'all_cars': all_cars,
        'car_filter': car_filter,
        
        # Reports
        'monthly_stats': monthly_stats,
        'completed_rentals': completed_rentals,
        'avg_booking_value': avg_booking_value,
        'avg_rental_days': avg_rental_days,
    }
    
    return render(request, 'rentals/admin_dashboard.html', context)


@login_required
def admin_rental_action(request, rental_id, action):
    """Handle rental actions like confirm, start, complete"""
    if request.user.userprofile.role != 'admin':
        messages.error(request, 'Access denied.')
        return redirect('home')
    
    rental = get_object_or_404(Rental, id=rental_id)
    
    if action == 'confirm':
        rental.status = 'confirmed'
        rental.save()
        messages.success(request, f'Booking {rental.booking_reference} confirmed.')
    elif action == 'start':
        rental.status = 'active'
        rental.save()
        messages.success(request, f'Booking {rental.booking_reference} started.')
    elif action == 'complete':
        rental.status = 'completed'
        rental.payment_status = 'paid'
        rental.save()
        messages.success(request, f'Booking {rental.booking_reference} completed.')
    elif action == 'cancel':
        rental.status = 'cancelled'
        # Calculate refund (90% = total - 10% cancellation charge)
        rental.refund_amount = rental.total_price * Decimal('0.90')
        rental.save()
        messages.success(request, f'Booking {rental.booking_reference} cancelled.')
    
    return redirect('rentals:admin_dashboard')


@login_required
def admin_payment_action(request, rental_id, action):
    """Handle payment actions like mark deposit paid, mark full payment"""
    if request.user.userprofile.role != 'admin':
        messages.error(request, 'Access denied.')
        return redirect('home')
    
    rental = get_object_or_404(Rental, id=rental_id)
    
    if action == 'deposit-paid':
        if not rental.deposit_amount:
            # Calculate deposit as 10% of total
            rental.deposit_amount = rental.total_price * Decimal('0.10')
        rental.deposit_paid = True
        rental.deposit_paid_at = timezone.now()
        rental.payment_status = 'paid'
        rental.save()
        messages.success(request, f'Deposit marked as paid for {rental.booking_reference}.')
    
    elif action == 'full-payment':
        rental.full_payment_paid = True
        rental.full_payment_paid_at = timezone.now()
        rental.pending_amount = 0
        rental.payment_status = 'paid'
        rental.save()
        messages.success(request, f'Full payment marked as paid for {rental.booking_reference}.')
    
    return redirect('rentals:admin_dashboard')


@login_required
def admin_process_cancellation(request, rental_id):
    """Process cancellation with 10% deduction"""
    if request.user.userprofile.role != 'admin':
        messages.error(request, 'Access denied.')
        return redirect('home')
    
    rental = get_object_or_404(Rental, id=rental_id)
    
    if rental.status != 'cancelled':
        # Calculate refund: 90% of total (10% cancellation charge)
        cancellation_charge = rental.total_price * Decimal('0.10')
        refund_amount = rental.total_price - cancellation_charge
        
        rental.status = 'cancelled'
        rental.refund_amount = refund_amount
        rental.payment_status = 'refunded'
        rental.save()
        
        # Create cancellation record
        Cancellation.objects.create(
            rental=rental,
            reason='Cancelled by admin',
            refund_amount=refund_amount,
            refund_processed=False
        )
        
        messages.success(request, f'Cancellation processed. Refund amount: ₹{refund_amount} (10% deduction applied).')
    else:
        messages.info(request, 'Booking already cancelled.')
    
    return redirect('rentals:admin_dashboard')


@login_required
def admin_process_refund(request, rental_id):
    """Process refund for cancelled booking"""
    if request.user.userprofile.role != 'admin':
        messages.error(request, 'Access denied.')
        return redirect('home')
    
    rental = get_object_or_404(Rental, id=rental_id)
    
    if rental.status == 'cancelled' and not rental.refund_processed:
        rental.refund_processed = True
        rental.refund_processed_at = timezone.now()
        rental.payment_status = 'refunded'
        rental.save()
        
        # Update cancellation record if exists
        try:
            cancellation = rental.cancellation
            cancellation.refund_processed = True
            cancellation.save()
        except Cancellation.DoesNotExist:
            pass
        
        messages.success(request, f'Refund of ₹{rental.refund_amount} processed for {rental.booking_reference}.')
    else:
        messages.error(request, 'Cannot process refund. Booking may already be refunded or not cancelled.')
    
    return redirect('rentals:admin_dashboard')


@login_required
def admin_respond_message(request, message_id):
    """Respond to contact message"""
    if request.user.userprofile.role != 'admin':
        messages.error(request, 'Access denied.')
        return redirect('home')
    
    message = get_object_or_404(ContactMessage, id=message_id)
    response = request.GET.get('response', '')
    
    if response:
        message.admin_response = response
        message.responded = True
        message.responded_at = timezone.now()
        message.save()
        messages.success(request, 'Response sent successfully.')
    else:
        messages.error(request, 'Response cannot be empty.')
    
    return redirect('rentals:admin_dashboard')


@login_required
def admin_manage_coupon(request):
    """Create or update coupon/offer"""
    if request.user.userprofile.role != 'admin':
        messages.error(request, 'Access denied.')
        return redirect('home')
    
    if request.method == 'POST':
        code = request.POST.get('code', '').upper()
        discount_type = request.POST.get('discount_type')
        discount_value = Decimal(request.POST.get('discount_value', 0))
        min_order_value = Decimal(request.POST.get('min_order_value', 0))
        max_discount = request.POST.get('max_discount')
        valid_from = request.POST.get('valid_from')
        valid_to = request.POST.get('valid_to')
        usage_limit = int(request.POST.get('usage_limit', 1))
        
        coupon_id = request.POST.get('coupon_id')
        
        if coupon_id:
            # Update existing coupon
            coupon = get_object_or_404(Coupon, id=coupon_id)
            coupon.code = code
            coupon.discount_type = discount_type
            coupon.discount_value = discount_value
            coupon.min_order_value = min_order_value
            if max_discount:
                coupon.max_discount = Decimal(max_discount)
            coupon.valid_from = valid_from
            coupon.valid_to = valid_to
            coupon.usage_limit = usage_limit
            coupon.save()
            messages.success(request, f'Coupon {code} updated successfully.')
        else:
            # Create new coupon
            Coupon.objects.create(
                code=code,
                discount_type=discount_type,
                discount_value=discount_value,
                min_order_value=min_order_value,
                max_discount=Decimal(max_discount) if max_discount else None,
                valid_from=valid_from,
                valid_to=valid_to,
                usage_limit=usage_limit
            )
            messages.success(request, f'Coupon {code} created successfully.')
    
    return redirect('rentals:admin_dashboard')


@login_required
def admin_toggle_coupon(request, coupon_id):
    """Activate or deactivate coupon"""
    if request.user.userprofile.role != 'admin':
        messages.error(request, 'Access denied.')
        return redirect('home')
    
    coupon = get_object_or_404(Coupon, id=coupon_id)
    coupon.active = not coupon.active
    coupon.save()
    
    status = 'activated' if coupon.active else 'deactivated'
    messages.success(request, f'Coupon {coupon.code} {status}.')
    
    return redirect('rentals:admin_dashboard')


# ============================================
# ENHANCED PAYMENT MANAGEMENT VIEWS
# ============================================

@login_required
def admin_payment_details(request, rental_id):
    """Detailed payment view for a specific rental"""
    if request.user.userprofile.role != 'admin':
        messages.error(request, 'Access denied.')
        return redirect('home')
    
    rental = get_object_or_404(Rental, id=rental_id)
    from payments.models import PaymentTransaction, PaymentConfirmation, RefundConfirmation
    
    # Get payment transactions
    transactions = rental.payment_transactions.all().order_by('-created_at')
    
    # Get payment confirmations
    confirmations = rental.payment_confirmations.all().order_by('-created_at')
    
    # Get refund confirmations
    refund_confirmations = rental.refund_confirmations.all().order_by('-created_at')
    
    # Get payment model if exists
    try:
        payment = rental.payment
    except:
        payment = None
    
    context = {
        'rental': rental,
        'transactions': transactions,
        'confirmations': confirmations,
        'refund_confirmations': refund_confirmations,
        'payment': payment,
    }
    
    return render(request, 'rentals/admin_payment_details.html', context)


@login_required
def admin_confirm_remaining_amount(request, rental_id):
    """Confirm the remaining amount payment for a rental"""
    if request.user.userprofile.role != 'admin':
        messages.error(request, 'Access denied.')
        return redirect('home')
    
    rental = get_object_or_404(Rental, id=rental_id)
    from payments.models import PaymentConfirmation, PaymentTransaction
    
    if request.method == 'POST':
        confirmation_notes = request.POST.get('confirmation_notes', '')
        payment_proof = request.POST.get('payment_proof', '')
        
        # Calculate remaining amount
        remaining_amount = rental.pending_amount
        
        if remaining_amount <= 0:
            messages.error(request, 'No remaining amount to confirm.')
            return redirect('rentals:admin_payment_details', rental_id=rental.id)
        
        # Create payment confirmation
        confirmation = PaymentConfirmation.objects.create(
            rental=rental,
            confirmation_type='remaining',
            amount=remaining_amount,
            is_confirmed=True,
            confirmed_by=request.user,
            confirmed_at=timezone.now(),
            confirmation_notes=confirmation_notes,
            payment_proof=payment_proof
        )
        
        # Update rental status
        rental.full_payment_paid = True
        rental.full_payment_paid_at = timezone.now()
        rental.pending_amount = 0
        rental.payment_status = 'paid'
        rental.save()
        
        # Create payment transaction record
        transaction = PaymentTransaction.objects.create(
            rental=rental,
            transaction_type='remaining',
            amount=remaining_amount,
            status='confirmed',
            transaction_id=f"RCPT{rental.booking_reference}{timezone.now().strftime('%Y%m%d%H%M%S')}",
            payment_method=rental.payment_method or 'cash',
            admin_verified=True,
            admin_verified_by=request.user,
            admin_verified_at=timezone.now(),
            notes=f"Confirmed by admin: {confirmation_notes}"
        )
        
        messages.success(request, f'Remaining amount of ₹{remaining_amount} confirmed for {rental.booking_reference}.')
        return redirect('rentals:admin_payment_details', rental_id=rental.id)
    
    # Show confirmation form
    context = {
        'rental': rental,
        'remaining_amount': rental.pending_amount,
    }
    return render(request, 'rentals/admin_confirm_remaining.html', context)


@login_required
def admin_confirm_refund_amount(request, rental_id):
    """Confirm the refund amount for a cancelled booking"""
    if request.user.userprofile.role != 'admin':
        messages.error(request, 'Access denied.')
        return redirect('home')
    
    rental = get_object_or_404(Rental, id=rental_id)
    from payments.models import RefundConfirmation
    
    if request.method == 'POST':
        confirmation_notes = request.POST.get('confirmation_notes', '')
        
        # Calculate refund amount (90% of total - 10% cancellation charge)
        cancellation_charge = rental.total_price * Decimal('0.10')
        refund_amount = rental.total_price - cancellation_charge
        
        # Create refund confirmation
        refund_confirm = RefundConfirmation.objects.create(
            rental=rental,
            refund_type='cancellation',
            original_amount=rental.total_price,
            cancellation_charge=cancellation_charge,
            refund_amount=refund_amount,
            is_confirmed=True,
            confirmed_by=request.user,
            confirmed_at=timezone.now(),
            confirmation_notes=confirmation_notes
        )
        
        # Update rental
        rental.refund_amount = refund_amount
        rental.refund_processed = True
        rental.refund_processed_at = timezone.now()
        rental.payment_status = 'refunded'
        rental.save()
        
        messages.success(request, f'Refund amount of ₹{refund_amount} confirmed for {rental.booking_reference}.')
        return redirect('rentals:admin_payment_details', rental_id=rental.id)
    
    # Show confirmation form
    cancellation_charge = rental.total_price * Decimal('0.10')
    refund_amount = rental.total_price - cancellation_charge
    
    context = {
        'rental': rental,
        'original_amount': rental.total_price,
        'cancellation_charge': cancellation_charge,
        'refund_amount': refund_amount,
    }
    return render(request, 'rentals/admin_confirm_refund.html', context)


@login_required
def admin_process_refund_payment(request, rental_id):
    """Process the actual refund payment to customer"""
    if request.user.userprofile.role != 'admin':
        messages.error(request, 'Access denied.')
        return redirect('home')
    
    rental = get_object_or_404(Rental, id=rental_id)
    from payments.models import RefundConfirmation
    
    if request.method == 'POST':
        refund_method = request.POST.get('refund_method', '')
        refund_reference = request.POST.get('refund_reference', '')
        
        # Get or create refund confirmation
        refund_confirm, created = RefundConfirmation.objects.get_or_create(
            rental=rental,
            defaults={
                'refund_type': 'cancellation',
                'original_amount': rental.total_price,
                'cancellation_charge': rental.total_price * Decimal('0.10'),
                'refund_amount': rental.refund_amount,
            }
        )
        
        # Update refund confirmation
        refund_confirm.refund_method = refund_method
        refund_confirm.refund_reference = refund_reference
        refund_confirm.is_processed = True
        refund_confirm.processed_at = timezone.now()
        refund_confirm.save()
        
        messages.success(request, f'Refund of ₹{rental.refund_amount} processed for {rental.booking_reference}.')
        return redirect('rentals:admin_payment_details', rental_id=rental.id)
    
    context = {
        'rental': rental,
        'refund_amount': rental.refund_amount,
    }
    return render(request, 'rentals/admin_process_refund.html', context)


@login_required
def admin_payment_transaction_history(request):
    """View all payment transactions"""
    if request.user.userprofile.role != 'admin':
        messages.error(request, 'Access denied.')
        return redirect('home')
    
    from payments.models import PaymentTransaction
    
    # Get filters
    transaction_type = request.GET.get('type', 'all')
    status = request.GET.get('status', 'all')
    
    # Base query
    transactions = PaymentTransaction.objects.select_related('rental', 'rental__car', 'rental__user').order_by('-created_at')
    
    if transaction_type != 'all':
        transactions = transactions.filter(transaction_type=transaction_type)
    
    if status != 'all':
        transactions = transactions.filter(status=status)
    
    # Statistics
    total_deposit = transactions.filter(transaction_type='deposit', status='confirmed').aggregate(Sum('amount'))['amount__sum'] or 0
    total_remaining = transactions.filter(transaction_type='remaining', status='confirmed').aggregate(Sum('amount'))['amount__sum'] or 0
    total_refunds = transactions.filter(transaction_type__in=['refund', 'cancellation_refund'], status='confirmed').aggregate(Sum('amount'))['amount__sum'] or 0
    
    context = {
        'transactions': transactions,
        'transaction_type': transaction_type,
        'status': status,
        'total_deposit': total_deposit,
        'total_remaining': total_remaining,
        'total_refunds': total_refunds,
    }
    
    return render(request, 'rentals/admin_transaction_history.html', context)


@login_required
def admin_verify_deposit(request, rental_id):
    """Verify deposit payment for a rental"""
    if request.user.userprofile.role != 'admin':
        messages.error(request, 'Access denied.')
        return redirect('home')
    
    rental = get_object_or_404(Rental, id=rental_id)
    from payments.models import PaymentTransaction, PaymentConfirmation
    
    if request.method == 'POST':
        verification_notes = request.POST.get('verification_notes', '')
        
        # Create payment confirmation for deposit
        confirmation = PaymentConfirmation.objects.create(
            rental=rental,
            confirmation_type='deposit',
            amount=rental.deposit_amount,
            is_confirmed=True,
            confirmed_by=request.user,
            confirmed_at=timezone.now(),
            confirmation_notes=verification_notes
        )
        
        # Update deposit status
        rental.deposit_paid = True
        rental.deposit_paid_at = timezone.now()
        rental.payment_status = 'paid'
        rental.pending_amount = rental.total_price - rental.deposit_amount
        rental.save()
        
        # Create transaction record
        transaction = PaymentTransaction.objects.create(
            rental=rental,
            transaction_type='deposit',
            amount=rental.deposit_amount,
            status='verified',
            transaction_id=f"DEP{rental.booking_reference}{timezone.now().strftime('%Y%m%d%H%M%S')}",
            admin_verified=True,
            admin_verified_by=request.user,
            admin_verified_at=timezone.now(),
            notes=f"Verified by admin: {verification_notes}"
        )
        
        messages.success(request, f'Deposit of ₹{rental.deposit_amount} verified for {rental.booking_reference}.')
        return redirect('rentals:admin_payment_details', rental_id=rental.id)
    
    context = {
        'rental': rental,
        'deposit_amount': rental.deposit_amount,
    }
    return render(request, 'rentals/admin_verify_deposit.html', context)


@login_required
def admin_pending_confirmations(request):
    """View all pending payment confirmations"""
    if request.user.userprofile.role != 'admin':
        messages.error(request, 'Access denied.')
        return redirect('home')
    
    from payments.models import PaymentConfirmation, RefundConfirmation
    
    # Get pending payment confirmations
    pending_deposits = PaymentConfirmation.objects.filter(
        confirmation_type='deposit',
        is_confirmed=False
    ).select_related('rental', 'rental__car', 'rental__user')
    
    pending_remaining = PaymentConfirmation.objects.filter(
        confirmation_type='remaining',
        is_confirmed=False
    ).select_related('rental', 'rental__car', 'rental__user')
    
    pending_refunds = RefundConfirmation.objects.filter(
        is_confirmed=False
    ).select_related('rental', 'rental__car', 'rental__user')
    
    # Get all confirmed payments (both deposit and full payments)
    confirmed_payments = PaymentConfirmation.objects.filter(
        is_confirmed=True
    ).select_related('rental', 'rental__car', 'rental__user').order_by('-confirmed_at')
    
    # NEW: Get rentals with deposit paid but remaining amount pending
    # These are bookings where user has paid deposit but not full payment
    pending_full_payments = Rental.objects.filter(
        deposit_paid=True,
        full_payment_paid=False,
        pending_amount__gt=0
    ).select_related('car', 'user').order_by('-created_at')
    
    context = {
        'pending_deposits': pending_deposits,
        'pending_remaining': pending_remaining,
        'pending_refunds': pending_refunds,
        'confirmed_payments': confirmed_payments,
        'pending_full_payments': pending_full_payments,
    }
    
    return render(request, 'rentals/admin_pending_confirmations.html', context)


@login_required
def admin_confirm_payment(request, transaction_id):
    """Confirm a pending payment transaction"""
    if request.user.userprofile.role != 'admin':
        messages.error(request, 'Access denied.')
        return redirect('home')
    
    transaction = get_object_or_404(PaymentTransaction, id=transaction_id)
    rental = transaction.rental
    
    # Update transaction status
    transaction.status = 'confirmed'
    transaction.admin_verified = True
    transaction.admin_verified_by = request.user
    transaction.admin_verified_at = timezone.now()
    transaction.save()
    
    # Update payment confirmation if exists
    confirmation = PaymentConfirmation.objects.filter(
        rental=rental,
        confirmation_type=transaction.transaction_type,
        is_confirmed=False
    ).first()
    
    if confirmation:
        confirmation.is_confirmed = True
        confirmation.confirmed_by = request.user
        confirmation.confirmed_at = timezone.now()
        confirmation.save()
    
    # Update rental based on transaction type
    if transaction.transaction_type == 'deposit':
        rental.deposit_paid = True
        rental.deposit_paid_at = timezone.now()
        rental.pending_amount = rental.total_price - rental.deposit_amount
        rental.payment_status = 'paid'
    elif transaction.transaction_type == 'remaining':
        rental.full_payment_paid = True
        rental.full_payment_paid_at = timezone.now()
        rental.pending_amount = 0
        rental.payment_status = 'paid'
    
    rental.save()
    
    messages.success(request, f'Payment of ₹{transaction.amount} confirmed for {rental.booking_reference}.')
    return redirect('rentals:admin_dashboard')


@login_required
def admin_all_payment_confirmations(request):
    """Show all payment confirmation records - both pending and confirmed"""
    if request.user.userprofile.role != 'admin':
        messages.error(request, 'Access denied.')
        return redirect('home')
    
    # Get filter parameter
    filter_type = request.GET.get('filter', 'all')
    
    # Get all payment confirmations (from PaymentConfirmation model)
    if filter_type == 'pending':
        pending_confirmations = PaymentConfirmation.objects.filter(
            is_confirmed=False
        ).select_related('rental', 'rental__car', 'rental__user').order_by('-created_at')
        confirmed_confirmations = PaymentConfirmation.objects.none()
    elif filter_type == 'confirmed':
        confirmed_confirmations = PaymentConfirmation.objects.filter(
            is_confirmed=True
        ).select_related('rental', 'rental__car', 'rental__user').order_by('-confirmed_at')
        pending_confirmations = PaymentConfirmation.objects.none()
    else:
        pending_confirmations = PaymentConfirmation.objects.filter(
            is_confirmed=False
        ).select_related('rental', 'rental__car', 'rental__user').order_by('-created_at')
        confirmed_confirmations = PaymentConfirmation.objects.filter(
            is_confirmed=True
        ).select_related('rental', 'rental__car', 'rental__user').order_by('-confirmed_at')
    
    # Calculate totals from PaymentConfirmation
    total_pending = sum(c.amount for c in pending_confirmations)
    total_confirmed = sum(c.amount for c in confirmed_confirmations)
    
    # Get all rentals with payments from Rental model
    # This includes ALL bookings with deposit paid or full payment done
    all_rentals_with_payment = Rental.objects.filter(
        deposit_paid=True
    ).select_related('car', 'user').order_by('-created_at')
    
    # Separate by payment status
    # 1. Deposit paid, full payment pending (remaining amount to be paid)
    pending_full_payment_rentals = all_rentals_with_payment.filter(
        full_payment_paid=False,
        pending_amount__gt=0
    )
    
    # 2. Full payment completed
    completed_payment_rentals = all_rentals_with_payment.filter(
        full_payment_paid=True
    )
    
    # Calculate totals from Rental model
    total_pending_from_rental = sum(r.pending_amount for r in pending_full_payment_rentals)
    total_completed_from_rental = sum(r.total_price for r in completed_payment_rentals)
    total_deposits_from_rental = sum(r.deposit_amount for r in all_rentals_with_payment)
    
    context = {
        'filter': filter_type,
        'pending_confirmations': pending_confirmations,
        'confirmed_confirmations': confirmed_confirmations,
        'total_pending': total_pending,
        'total_confirmed': total_confirmed,
        
        # Rental-based payment data
        'all_rentals_with_payment': all_rentals_with_payment,
        'pending_full_payment_rentals': pending_full_payment_rentals,
        'completed_payment_rentals': completed_payment_rentals,
        'total_pending_from_rental': total_pending_from_rental,
        'total_completed_from_rental': total_completed_from_rental,
        'total_deposits_from_rental': total_deposits_from_rental,
    }
    
    return render(request, 'rentals/admin_all_payment_confirmations.html', context)


@login_required
def admin_full_payments(request):
    """Show all full paid payment records - for admin management"""
    if request.user.userprofile.role != 'admin':
        messages.error(request, 'Access denied. Admin only.')
        return redirect('home')
    
    # Get filter parameter
    filter_type = request.GET.get('filter', 'all')
    
    # Get all rentals with full payment paid
    # This includes all bookings where full_payment_paid=True
    full_paid_rentals = Rental.objects.filter(
        full_payment_paid=True
    ).select_related('car', 'user').order_by('-created_at')
    
    # Additional filters
    if filter_type == 'completed':
        full_paid_rentals = full_paid_rentals.filter(status='completed')
    elif filter_type == 'active':
        full_paid_rentals = full_paid_rentals.filter(status='active')
    elif filter_type == 'confirmed':
        full_paid_rentals = full_paid_rentals.filter(status='confirmed')
    elif filter_type == 'cancelled':
        full_paid_rentals = full_paid_rentals.filter(status='cancelled')
    
    # Calculate totals
    total_full_paid_amount = sum(r.total_price for r in full_paid_rentals)
    total_deposits = sum(r.deposit_amount for r in full_paid_rentals)
    
    # Get payment confirmations for full payments
    full_payment_confirmations = PaymentConfirmation.objects.filter(
        confirmation_type='full',
        is_confirmed=True
    ).select_related('rental', 'rental__car', 'rental__user').order_by('-confirmed_at')
    
    # Get payment transactions for full payments
    full_payment_transactions = PaymentTransaction.objects.filter(
        transaction_type='full',
        status__in=['confirmed', 'verified']
    ).select_related('rental', 'rental__car', 'rental__user').order_by('-created_at')
    
    # Get deposit payments (when full payment is done, deposit is also included)
    deposit_confirmations = PaymentConfirmation.objects.filter(
        confirmation_type='deposit',
        is_confirmed=True
    ).select_related('rental', 'rental__car', 'rental__user').order_by('-confirmed_at')
    
    context = {
        'filter': filter_type,
        'full_paid_rentals': full_paid_rentals,
        'total_full_paid_amount': total_full_paid_amount,
        'total_deposits': total_deposits,
        'full_payment_confirmations': full_payment_confirmations,
        'full_payment_transactions': full_payment_transactions,
        'deposit_confirmations': deposit_confirmations,
    }
    
    return render(request, 'rentals/admin_full_payments.html', context)


@login_required
def admin_refund_section(request):
    """New unified Refund Section - Show all cancelled bookings with refund management"""
    if request.user.userprofile.role != 'admin':
        messages.error(request, 'Access denied. Admin only.')
        return redirect('home')
    
    # Get filter parameter
    filter_type = request.GET.get('filter', 'all')
    
    # Get all cancelled rentals
    all_cancelled_rentals = Rental.objects.filter(
        status='cancelled'
    ).select_related('car', 'user').order_by('-created_at')
    
    # Get all refund confirmations
    from payments.models import RefundConfirmation
    
    # 1. Refund Pending - cancelled but refund not processed (no confirmation record yet)
    refund_pending_rentals = all_cancelled_rentals.filter(
        refund_processed=False,
        refund_amount__gt=0
    ).select_related('car', 'user')
    
    # 2. Refund Confirmed - refund confirmed but not yet processed
    refund_confirmed = RefundConfirmation.objects.filter(
        is_confirmed=True,
        is_processed=False
    ).select_related('rental', 'rental__car', 'rental__user')
    
    # 3. Refund Processed - refund completed
    refund_processed = RefundConfirmation.objects.filter(
        is_processed=True
    ).select_related('rental', 'rental__car', 'rental__user').order_by('-processed_at')
    
    # 4. Refund Cancelled - refund was cancelled
    refund_cancelled = RefundConfirmation.objects.filter(
        is_confirmed=False,
        is_processed=False,
        confirmed_at__isnull=False
    ).select_related('rental', 'rental__car', 'rental__user')
    
    # Calculate totals
    total_refund_pending = sum(r.refund_amount for r in refund_pending_rentals if r.refund_amount)
    total_refund_confirmed = sum(r.refund_amount for r in refund_confirmed if r.refund_amount)
    total_refund_processed = sum(r.refund_amount for r in refund_processed if r.refund_amount)
    total_refund_cancelled = sum(r.refund_amount for r in refund_cancelled if r.refund_amount)
    
    # Apply additional filters if needed
    if filter_type == 'pending':
        display_rentals = refund_pending_rentals
    elif filter_type == 'confirmed':
        display_rentals = refund_confirmed
    elif filter_type == 'processed':
        display_rentals = refund_processed
    elif filter_type == 'cancelled':
        display_rentals = refund_cancelled
    else:
        display_rentals = all_cancelled_rentals
    
    context = {
        'filter': filter_type,
        'all_cancelled_rentals': all_cancelled_rentals,
        'refund_pending_rentals': refund_pending_rentals,
        'refund_confirmed': refund_confirmed,
        'refund_processed': refund_processed,
        'refund_cancelled': refund_cancelled,
        'display_rentals': display_rentals,
        'total_refund_pending': total_refund_pending,
        'total_refund_confirmed': total_refund_confirmed,
        'total_refund_processed': total_refund_processed,
        'total_refund_cancelled': total_refund_cancelled,
    }
    
    return render(request, 'rentals/admin_refund_section.html', context)


@login_required
def admin_refund_confirmations(request):
    """Show all cancelled bookings with refund management - Main Refund Section"""
    if request.user.userprofile.role != 'admin':
        messages.error(request, 'Access denied. Admin only.')
        return redirect('home')
    
    # Get filter parameter
    filter_type = request.GET.get('filter', 'all')
    
    # Get all cancelled rentals (bookings that were cancelled)
    all_cancelled_rentals = Rental.objects.filter(
        status='cancelled'
    ).select_related('car', 'user').order_by('-created_at')
    
    # Get refund confirmations from payments model
    from payments.models import RefundConfirmation
    
    # 1. Pending Refunds - cancelled but refund not processed (from Rental model)
    pending_refunds = Rental.objects.filter(
        status='cancelled',
        refund_processed=False,
        refund_amount__gt=0
    ).select_related('car', 'user').order_by('-created_at')
    
    # Total pending refunds from rental records
    total_pending_refunds = sum(r.refund_amount for r in pending_refunds if r.refund_amount)
    pending_refunds_count = pending_refunds.count()
    
    # 2. Confirmed Refunds - refund confirmed by admin but not processed yet
    confirmed_refunds = RefundConfirmation.objects.filter(
        is_confirmed=True,
        is_processed=False
    ).select_related('rental', 'rental__car', 'rental__user').order_by('-confirmed_at')
    
    confirmed_refunds_count = confirmed_refunds.count()
    
    # 3. Processed Refunds - refund completed
    processed_refunds = RefundConfirmation.objects.filter(
        is_processed=True
    ).select_related('rental', 'rental__car', 'rental__user').order_by('-processed_at')
    
    processed_refunds_count = processed_refunds.count()
    
    # Apply filter to display rentals
    if filter_type == 'pending':
        display_rentals = pending_refunds
    elif filter_type == 'confirmed':
        display_rentals = confirmed_refunds
    elif filter_type == 'processed':
        display_rentals = processed_refunds
    else:
        display_rentals = all_cancelled_rentals
    
    context = {
        'filter': filter_type,
        'all_cancelled_rentals': all_cancelled_rentals,
        'pending_refunds': pending_refunds,
        'confirmed_refunds': confirmed_refunds,
        'processed_refunds': processed_refunds,
        'display_rentals': display_rentals,
        'total_pending_refunds': total_pending_refunds,
        'pending_refunds_count': pending_refunds_count,
        'confirmed_refunds_count': confirmed_refunds_count,
        'processed_refunds_count': processed_refunds_count,
    }
    
    return render(request, 'rentals/admin_refund_confirmations.html', context)
