from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
from django.core.files.storage import default_storage

class CarCategory(models.Model):
    name = models.CharField(max_length=50, unique=True)
    description = models.TextField(blank=True)

    def __str__(self):
        return self.name

class Car(models.Model):
    BRAND_CHOICES = [
        ('toyota', 'Toyota'),
        ('honda', 'Honda'),
        ('ford', 'Ford'),
        ('bmw', 'BMW'),
        ('audi', 'Audi'),
        ('mercedes', 'Mercedes'),
        ('tata', 'Tata'),
        ('mahindra', 'Mahindra'),
        ('suzuki', 'Suzuki'),
        ('kia', 'Kia'),
        ('hyundai', 'Hyundai'),
    ]

    FUEL_CHOICES = [
        ('petrol', 'Petrol'),
        ('diesel', 'Diesel'),
        ('electric', 'Electric'),
        ('hybrid', 'Hybrid'),
    ]

    TRANSMISSION_CHOICES = [
        ('manual', 'Manual'),
        ('automatic', 'Automatic'),
    ]

    name = models.CharField(max_length=100)
    brand = models.CharField(max_length=20, choices=BRAND_CHOICES)
    category = models.ForeignKey(CarCategory, on_delete=models.SET_NULL, null=True, blank=True)
    price_per_day = models.DecimalField(max_digits=10, decimal_places=2)
    weekend_price = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    festival_price = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    image = models.ImageField(upload_to='cars/', blank=True, null=True)
    description = models.TextField()
    available = models.BooleanField(default=True)
    stock = models.PositiveIntegerField(default=1)
    model_year = models.PositiveIntegerField(blank=True, null=True)
    color = models.CharField(max_length=50, blank=True)
    fuel_type = models.CharField(max_length=20, choices=FUEL_CHOICES, blank=True)
    seating_capacity = models.PositiveIntegerField(blank=True, null=True)
    transmission = models.CharField(max_length=20, choices=TRANSMISSION_CHOICES, blank=True)
    mileage = models.PositiveIntegerField(blank=True, null=True)  # km/l
    engine_capacity = models.PositiveIntegerField(blank=True, null=True)  # cc
    features = models.JSONField(default=list)  # list of features like AC, GPS, etc.
    location = models.CharField(max_length=100, blank=True)  # city or area
    vendor = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='cars')
    rating = models.DecimalField(max_digits=3, decimal_places=2, default=0)
    review_count = models.PositiveIntegerField(default=0)
    security_deposit = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    insurance_included = models.BooleanField(default=True)
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.brand} {self.name}"

    def is_available(self):
        return self.available and self.stock > 0

    def is_available_for_dates(self, start_date, end_date):
        """
        Check if the car is available for the given date range.
        Returns True if available, False if already booked.
        """
        from rentals.models import Rental
        
        # Check for any overlapping bookings that are not cancelled
        conflicting_rentals = Rental.objects.filter(
            car=self,
            status__in=['pending', 'confirmed', 'active'],
            start_date__lte=end_date,
            end_date__gte=start_date
        )
        
        return not conflicting_rentals.exists()

    def get_current_price(self, date=None):
        # Dynamic pricing logic
        if date and date.weekday() >= 5:  # weekend
            return self.weekend_price or self.price_per_day
        # Add festival logic later
        return self.price_per_day

    class Meta:
        ordering = ['price_per_day']

class CarAvailability(models.Model):
    car = models.ForeignKey(Car, on_delete=models.CASCADE, related_name='availabilities')
    date = models.DateField()
    available = models.BooleanField(default=True)
    price_modifier = models.DecimalField(max_digits=5, decimal_places=2, default=1.0)  # multiplier

    class Meta:
        unique_together = ('car', 'date')

class CarImage(models.Model):
    car = models.ForeignKey(Car, on_delete=models.CASCADE, related_name='images')
    image = models.ImageField(upload_to='cars/')
    alt_text = models.CharField(max_length=255, blank=True)

    def __str__(self):
        return f"Image for {self.car.name}"
