from django.contrib import admin
from .models import Car, CarImage

class CarImageInline(admin.TabularInline):
    model = CarImage
    extra = 1

@admin.register(Car)
class CarAdmin(admin.ModelAdmin):
    list_display = ('name', 'brand', 'price_per_day', 'available', 'stock', 'is_available')
    list_filter = ('brand', 'available', 'fuel_type', 'transmission')
    search_fields = ('name', 'brand', 'description')
    readonly_fields = ('id',)
    fieldsets = (
        ('Basic Information', {
            'fields': ('name', 'brand', 'description')
        }),
        ('Pricing & Availability', {
            'fields': ('price_per_day', 'available', 'stock')
        }),
        ('Specifications', {
            'fields': ('model_year', 'color', 'fuel_type', 'seating_capacity', 'transmission')
        }),
        ('Media', {
            'fields': ('image',)
        }),
    )
    # inlines = [CarImageInline]

    def is_available(self, obj):
        return obj.is_available()
    is_available.boolean = True
    is_available.short_description = 'Available for Rent'

# @admin.register(CarImage)
# class CarImageAdmin(admin.ModelAdmin):
#     list_display = ('car', 'image', 'alt_text')
#     list_filter = ('car',)
#     search_fields = ('car__name', 'alt_text')
