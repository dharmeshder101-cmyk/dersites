from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q, Avg, Count
from django.core.paginator import Paginator
from .models import Car, CarCategory
from rentals.models import Rental, Review
from datetime import datetime, date

def car_list(request):
    # Get all available cars
    cars = Car.objects.filter(available=True).select_related('category', 'vendor').prefetch_related('review_set', 'images')

    # Simple filters - only 3 main features
    search = request.GET.get('search', '')
    brand_filter = request.GET.get('brand', '')
    category_filter = request.GET.get('category', '')
    sort_by = request.GET.get('sort', 'price_per_day')

    # Apply search
    if search:
        cars = cars.filter(Q(name__icontains=search) | Q(brand__icontains=search))

    # Apply brand filter
    if brand_filter:
        cars = cars.filter(brand=brand_filter)

    # Apply category filter
    if category_filter:
        try:
            category_id = int(category_filter)
            cars = cars.filter(category_id=category_id)
        except (ValueError, TypeError):
            pass

    # Apply sorting
    if sort_by == 'price_asc':
        cars = cars.order_by('price_per_day')
    elif sort_by == 'price_desc':
        cars = cars.order_by('-price_per_day')
    elif sort_by == 'rating':
        cars = cars.annotate(avg_rating=Avg('review__rating')).order_by('-avg_rating')
    elif sort_by == 'newest':
        cars = cars.order_by('-created_at')
    else:
        cars = cars.order_by('price_per_day')

    # Pagination - 9 cars per page
    paginator = Paginator(cars, 9)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    # Get all unique brands from available cars
    brand_list = Car.objects.filter(available=True).values_list('brand', flat=True).distinct()
    brand_choices = []
    for b in brand_list:
        if b:
            count = Car.objects.filter(available=True, brand=b).count()
            brand_choices.append({'brand': b, 'car_count': count})

    # Get all categories
    categories = CarCategory.objects.all()

    context = {
        'page_obj': page_obj,
        'search': search,
        'selected_brand': brand_filter,
        'selected_category': category_filter,
        'sort_by': sort_by,
        'brands': brand_choices,
        'categories': categories,
    }
    return render(request, 'cars/car_list.html', context)

def car_detail(request, car_id):
    car = get_object_or_404(Car, id=car_id, available=True)

    # Clear any existing messages
    storage = messages.get_messages(request)
    for _ in storage:
        pass

    # Get reviews for this car
    reviews = Review.objects.filter(car=car).select_related('user').order_by('-created_at')

    # Calculate average rating
    avg_rating = reviews.aggregate(Avg('rating'))['rating__avg'] or 0
    review_count = reviews.count()

    # Similar cars (same category or brand)
    similar_cars = Car.objects.filter(
        available=True
    ).exclude(id=car.id).filter(
        Q(category=car.category) | Q(brand=car.brand)
    )[:4]

    # Check availability for next 30 days
    from datetime import date, timedelta
    today = date.today()
    availability_dates = []
    for i in range(30):
        check_date = today + timedelta(days=i)
        is_available = not Rental.objects.filter(
            car=car,
            status__in=['confirmed', 'active'],
            start_date__lte=check_date,
            end_date__gte=check_date
        ).exists()
        availability_dates.append({
            'date': check_date,
            'available': is_available
        })

    context = {
        'car': car,
        'reviews': reviews,
        'avg_rating': avg_rating,
        'review_count': review_count,
        'similar_cars': similar_cars,
        'availability_dates': availability_dates,
    }
    return render(request, 'cars/car_detail.html', context)

@login_required
def rent_car(request, car_id):
    car = get_object_or_404(Car, id=car_id, available=True)

    # Clear any existing messages
    storage = messages.get_messages(request)
    for _ in storage:
        pass

    if request.method == 'POST':
        start_date = request.POST.get('start_date')
        end_date = request.POST.get('end_date')

        if start_date and end_date:
            start = datetime.strptime(start_date, '%Y-%m-%d').date()
            end = datetime.strptime(end_date, '%Y-%m-%d').date()
            today = date.today()

            if start < today:
                messages.error(request, 'Pickup date cannot be in the past.')
                return redirect('car_detail', car_id=car.id)

            if end < today:
                messages.error(request, 'Return date cannot be in the past.')
                return redirect('car_detail', car_id=car.id)

            if start >= end:
                messages.error(request, 'End date must be after start date.')
                return redirect('car_detail', car_id=car.id)

            days = (end - start).days
            total_price = car.price_per_day * days

            # Check availability
            conflicting_rentals = Rental.objects.filter(
                car=car,
                status__in=['confirmed', 'active']
            ).filter(
                Q(start_date__lte=end) & Q(end_date__gte=start)
            )

            if conflicting_rentals.exists():
                messages.error(request, 'Car is not available for selected dates.')
                return redirect('car_detail', car_id=car.id)

            rental = Rental.objects.create(
                user=request.user,
                car=car,
                start_date=start,
                end_date=end,
                total_price=total_price,
                status='pending'
            )

            messages.success(request, f'Rental request submitted! Total: ₹{total_price}')
            return redirect('rentals:rentals')

    min_date = date.today().strftime('%Y-%m-%d')
    
    return render(request, 'cars/rent_car.html', {'car': car, 'min_date': min_date})
