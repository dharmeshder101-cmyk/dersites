# First Time User 10% Offer Implementation Plan

## Task
Implement automatic 10% discount for first-time users on their first booking only (no promo code required).

## Plan

### Step 1: Add field to UserProfile
- File: `accounts/models.py`
- Add `is_first_booking` field to track if user has completed a booking

### Step 2: Modify payment calculation in views
- File: `rentals/views.py`
- In `payment_page` function, check if user has any completed/confirmed rentals
- If first booking, apply 10% discount automatically

### Step 3: Update payment template
- File: `templates/cars/payment.html`
- Display the first-time user discount if applicable

### Step 4: Update process_payment to mark first booking as used
- File: `rentals/views.py`
- After successful payment, set user's `is_first_booking` to False
