from django.db import models
from django.contrib.auth.models import User
from rentals.models import Rental
from cars.models import Car
from django.utils import timezone

class AnalyticsEvent(models.Model):
    EVENT_TYPES = [
        ('page_view', 'Page View'),
        ('booking_started', 'Booking Started'),
        ('booking_completed', 'Booking Completed'),
        ('payment_failed', 'Payment Failed'),
        ('user_registered', 'User Registered'),
        ('car_searched', 'Car Searched'),
        ('coupon_used', 'Coupon Used'),
    ]

    event_type = models.CharField(max_length=50, choices=EVENT_TYPES)
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    session_id = models.CharField(max_length=100)
    data = models.JSONField()  # Store event-specific data
    ip_address = models.GenericIPAddressField()
    user_agent = models.TextField()
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        indexes = [
            models.Index(fields=['event_type', 'created_at']),
            models.Index(fields=['user', 'created_at']),
        ]

class DashboardMetric(models.Model):
    METRIC_TYPES = [
        ('total_bookings', 'Total Bookings'),
        ('total_revenue', 'Total Revenue'),
        ('active_users', 'Active Users'),
        ('conversion_rate', 'Conversion Rate'),
        ('average_booking_value', 'Average Booking Value'),
        ('car_utilization', 'Car Utilization Rate'),
    ]

    metric_type = models.CharField(max_length=50, choices=METRIC_TYPES, unique=True)
    value = models.DecimalField(max_digits=15, decimal_places=2)
    period = models.CharField(max_length=20)  # daily, weekly, monthly
    date = models.DateField()
    created_at = models.DateTimeField(auto_now_add=True)

class RevenueAnalytics(models.Model):
    date = models.DateField(unique=True)
    total_revenue = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    booking_revenue = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    add_on_revenue = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    refund_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    net_revenue = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    transaction_count = models.PositiveIntegerField(default=0)

class UserAnalytics(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    total_bookings = models.PositiveIntegerField(default=0)
    total_spent = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    average_rating_given = models.DecimalField(max_digits=3, decimal_places=2, default=0)
    last_booking_date = models.DateField(null=True, blank=True)
    preferred_car_types = models.JSONField(default=list)
    signup_date = models.DateField(auto_now_add=True)
    is_active = models.BooleanField(default=True)

class CarAnalytics(models.Model):
    car = models.OneToOneField(Car, on_delete=models.CASCADE)
    total_bookings = models.PositiveIntegerField(default=0)
    total_revenue = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    average_rating = models.DecimalField(max_digits=3, decimal_places=2, default=0)
    utilization_rate = models.DecimalField(max_digits=5, decimal_places=2, default=0)  # percentage
    popular_months = models.JSONField(default=list)
    maintenance_cost = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    last_booked = models.DateField(null=True, blank=True)

class FraudAlert(models.Model):
    ALERT_TYPES = [
        ('suspicious_booking', 'Suspicious Booking Pattern'),
        ('payment_anomaly', 'Payment Anomaly'),
        ('account_takeover', 'Account Takeover Attempt'),
        ('bulk_booking', 'Bulk Booking Suspicion'),
    ]

    alert_type = models.CharField(max_length=50, choices=ALERT_TYPES)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    rental = models.ForeignKey(Rental, on_delete=models.SET_NULL, null=True, blank=True)
    risk_score = models.DecimalField(max_digits=5, decimal_places=2)  # 0-100
    details = models.JSONField()
    resolved = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

class PerformanceMetric(models.Model):
    endpoint = models.CharField(max_length=200)
    method = models.CharField(max_length=10)
    response_time = models.DecimalField(max_digits=8, decimal_places=4)  # in seconds
    status_code = models.PositiveIntegerField()
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        indexes = [
            models.Index(fields=['endpoint', 'created_at']),
            models.Index(fields=['response_time']),
        ]

class ABTest(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()
    variants = models.JSONField()  # {'A': 'variant_a', 'B': 'variant_b'}
    start_date = models.DateTimeField()
    end_date = models.DateTimeField()
    active = models.BooleanField(default=True)
    results = models.JSONField(default=dict)

class MarketingCampaign(models.Model):
    name = models.CharField(max_length=100)
    campaign_type = models.CharField(max_length=50, choices=[
        ('email', 'Email Campaign'),
        ('social', 'Social Media'),
        ('paid_ads', 'Paid Advertising'),
        ('referral', 'Referral Program'),
    ])
    start_date = models.DateField()
    end_date = models.DateField()
    budget = models.DecimalField(max_digits=10, decimal_places=2)
    target_audience = models.JSONField(default=dict)
    metrics = models.JSONField(default=dict)  # impressions, clicks, conversions
    roi = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True)
