from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from .forms import CustomUserCreationForm
from .models import UserProfile

def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Registration successful!')
            return redirect(get_role_based_redirect(user))
    else:
        form = CustomUserCreationForm()
    return render(request, 'accounts/register.html', {'form': form})

def user_login(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        # Find user by email and authenticate with username
        try:
            user_obj = User.objects.get(email=email)
            user = authenticate(request, username=user_obj.username, password=password)
            if user:
                login(request, user)
                return redirect(get_role_based_redirect(user))
            else:
                messages.error(request, 'Invalid credentials.')
        except User.DoesNotExist:
            messages.error(request, 'Invalid credentials.')
    return render(request, 'accounts/login.html')

def user_logout(request):
    logout(request)
    return redirect('home')

@login_required
def profile(request):
    profile, created = UserProfile.objects.get_or_create(user=request.user)
    if request.method == 'POST':
        profile.phone = request.POST.get('phone', '')
        profile.address = request.POST.get('address', '')
        profile.date_of_birth = request.POST.get('date_of_birth') or None
        profile.license_number = request.POST.get('license_number', '') or ''
        if profile.role == 'vendor':
            profile.company_name = request.POST.get('company_name', '')
        profile.save()
        messages.success(request, 'Profile updated!')
        return redirect('profile')
    return render(request, 'accounts/profile.html', {'profile': profile})

def get_role_based_redirect(user):
    """Return appropriate redirect URL based on user role"""
    try:
        profile = user.userprofile
        role_redirects = {
            'admin': 'admin_dashboard',
            'vendor': 'vendor_dashboard',
            'driver': 'driver_dashboard',
            'customer': 'home'
        }
        return role_redirects.get(profile.role, 'home')
    except UserProfile.DoesNotExist:
        return 'home'
