from django.db import models
from django.contrib.auth.models import User

class UserProfile(models.Model):
    ROLE_CHOICES = [
        ('customer', 'Customer'),
        ('driver', 'Driver'),
        ('vendor', 'Vendor'),
        ('admin', 'Admin'),
    ]

    user = models.OneToOneField(User, on_delete=models.CASCADE)
    phone = models.CharField(max_length=15, blank=True)
    address = models.TextField(blank=True)
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='customer')
    date_of_birth = models.DateField(blank=True, null=True)
    license_number = models.CharField(max_length=50, blank=True)
    company_name = models.CharField(max_length=100, blank=True)  # for vendors
    wallet_balance = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    loyalty_points = models.PositiveIntegerField(default=0)
    
    # First time booking offer tracking
    is_first_booking = models.BooleanField(default=True, help_text="True if user hasn't completed their first booking yet")

    def __str__(self):
        return f"{self.user.username} - {self.role}"
