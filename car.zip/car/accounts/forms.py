import re
from django import forms
from django.contrib.auth.models import User
from django.contrib.auth import get_user_model
from .models import UserProfile

class CustomUserCreationForm(forms.Form):
    email = forms.EmailField(required=True, widget=forms.EmailInput(attrs={
        'class': 'form-control',
        'placeholder': 'Enter your email',
        'pattern': '[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
        'title': 'Please enter a valid email address'
    }))
    phone = forms.CharField(max_length=10, min_length=10, required=False, widget=forms.TextInput(attrs={
        'class': 'form-control',
        'placeholder': 'Enter 10-digit phone number',
        'pattern': '^[6-9]\d{9}$',
        'title': 'Please enter a valid 10-digit Indian phone number (starting with 6-9)'
    }))
    password1 = forms.CharField(widget=forms.PasswordInput(attrs={
        'class': 'form-control',
        'placeholder': 'Enter password (min 8 characters)',
        'minlength': '8',
        'title': 'Password must be at least 8 characters and contain at least one letter'
    }), label='Password')
    password2 = forms.CharField(widget=forms.PasswordInput(attrs={
        'class': 'form-control',
        'placeholder': 'Confirm password'
    }), label='Confirm Password')

    def clean_email(self):
        email = self.cleaned_data['email']
        email = email.lower()
        
        # Validate email format
        email_regex = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        if not re.match(email_regex, email):
            raise forms.ValidationError('Please enter a valid email address.')
        
        return email

    def clean_phone(self):
        phone = self.cleaned_data.get('phone', '')
        if phone:
            # Remove any spaces or dashes
            phone = re.sub(r'[\s\-]', '', phone)
            
            # Check if it's exactly 10 digits
            if not re.match(r'^\d{10}$', phone):
                raise forms.ValidationError('Phone number must be exactly 10 digits.')
            
            # Check if it starts with valid Indian mobile number prefix (6-9)
            if not re.match(r'^[6-9]\d{9}$', phone):
                raise forms.ValidationError('Please enter a valid Indian phone number (starting with 6-9).')
            
            return phone
        return phone

    def clean_password1(self):
        password1 = self.cleaned_data.get('password1', '')
        
        if password1:
            # Check minimum length of 8 characters
            if len(password1) < 8:
                raise forms.ValidationError('Password must be at least 8 characters long.')
            
            # Check if password contains at least one letter (not only digits)
            if password1.isdigit():
                raise forms.ValidationError('Password must contain at least one letter. It cannot be only digits.')
            
        return password1

    def clean(self):
        cleaned_data = super().clean()
        password1 = cleaned_data.get('password1')
        password2 = cleaned_data.get('password2')
        
        if password1 and password2 and password1 != password2:
            raise forms.ValidationError('Passwords do not match.')
        
        return cleaned_data

    def save(self):
        email = self.cleaned_data['email']
        phone = self.cleaned_data.get('phone', '')
        password = self.cleaned_data['password1']
        
        # Create user with email as username (allow duplicates by adding random suffix)
        base_username = email.split('@')[0].lower()
        username = base_username
        counter = 1
        User = get_user_model()
        while User.objects.filter(username=username).exists():
            username = f"{base_username}{counter}"
            counter += 1
        
        user = User.objects.create_user(
            username=username,
            email=email,
            password=password
        )
        UserProfile.objects.create(user=user, phone=phone)
        return user
