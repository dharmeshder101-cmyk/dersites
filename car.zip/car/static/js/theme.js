// Color themes that cycle every 3 seconds
const themes = [
    {
        bg: '#F8FAFC',
        primary: '#A8DADC',
        accent: '#457B9D',
        text: '#2E2E2E'
    },
    {
        bg: '#FFF5F7',
        primary: '#F8C8DC',
        accent: '#CDB4DB',
        text: '#4A4A4A'
    },
    {
        bg: '#F4F9FF',
        primary: '#BFD7ED',
        accent: '#6CA6C1',
        text: '#2F3E46'
    },
    {
        bg: '#F6FFF8',
        primary: '#CDE7BE',
        accent: '#7FB77E',
        text: '#344E41'
    },
    {
        bg: '#FAF3E0',
        primary: '#EADBC8',
        accent: '#C1A57B',
        text: '#3A3A3A'
    }
];

let currentThemeIndex = 0;

function applyTheme(theme) {
    document.documentElement.style.setProperty('--bg-color', theme.bg);
    document.documentElement.style.setProperty('--primary-color', theme.primary);
    document.documentElement.style.setProperty('--accent-color', theme.accent);
    document.documentElement.style.setProperty('--text-color', theme.text);

    document.body.style.backgroundColor = theme.bg;
    document.body.style.color = theme.text;
}

function cycleTheme() {
    applyTheme(themes[currentThemeIndex]);
    currentThemeIndex = (currentThemeIndex + 1) % themes.length;
}

// Apply initial theme
applyTheme(themes[0]);

// Cycle themes every 3 seconds
setInterval(cycleTheme, 3000);

// Car Slideshow Functionality
function initSlideshow() {
    const slideshow = document.querySelector('.car-slideshow');
    if (!slideshow) return;

    const slides = slideshow.querySelectorAll('.slide');
    const nav = slideshow.querySelector('.slideshow-nav');
    const currentSlideEl = slideshow.querySelector('.current-slide');
    const totalSlidesEl = slideshow.querySelector('.total-slides');
    
    if (slides.length === 0) return;

    let currentSlide = 0;
    const totalSlides = slides.length;

    // Initialize all slides
    slides.forEach((slide, index) => {
        slide.classList.remove('active', 'prev', 'next');
        if (index === 0) {
            slide.classList.add('active');
        }
    });

    // Update total slides counter
    if (totalSlidesEl) {
        totalSlidesEl.textContent = totalSlides;
    }

    // Create navigation dots
    for (let i = 0; i < totalSlides; i++) {
        const dot = document.createElement('div');
        dot.className = 'slide-dot' + (i === 0 ? ' active' : '');
        dot.addEventListener('click', () => goToSlide(i));
        nav.appendChild(dot);
    }

    const dots = slideshow.querySelectorAll('.slide-dot');

    function updateSlideClasses(newIndex) {
        slides.forEach((slide, index) => {
            slide.classList.remove('active', 'prev', 'next');
            
            if (index === newIndex) {
                slide.classList.add('active');
            } else if (index === (newIndex - 1 + totalSlides) % totalSlides) {
                slide.classList.add('prev');
            } else if (index === (newIndex + 1) % totalSlides) {
                slide.classList.add('next');
            }
        });
    }

    function goToSlide(index) {
        // Remove active class from current dot
        dots[currentSlide].classList.remove('active');

        // Update current slide index
        currentSlide = index;

        // Add active class to new dot
        dots[currentSlide].classList.add('active');

        // Update slide classes for swipe animation
        updateSlideClasses(currentSlide);

        // Update counter
        if (currentSlideEl) {
            currentSlideEl.textContent = currentSlide + 1;
        }
    }

    function nextSlide() {
        const nextIndex = (currentSlide + 1) % totalSlides;
        goToSlide(nextIndex);
    }

    // Auto-slide every 2 seconds
    setInterval(nextSlide, 4000);
}

// Add some 3D animation effects
document.addEventListener('DOMContentLoaded', function() {
    // Initialize slideshow
    initSlideshow();

    // Removed floating animation for car cards

    // Date Picker Functionality
    const dateInputs = document.querySelectorAll('input[type="date"]');
    dateInputs.forEach(input => {
        const btn = input.nextElementSibling;
        const calendar = input.parentElement.nextElementSibling;

        btn.addEventListener('click', () => {
            calendar.classList.toggle('hidden');
            if (!calendar.classList.contains('hidden')) {
                renderCalendar(calendar, input);
            }
        });

        input.addEventListener('change', () => {
            calendar.classList.add('hidden');
        });
    });

    function renderCalendar(calendar, input) {
        const currentDate = input.value ? new Date(input.value) : new Date();
        const year = currentDate.getFullYear();
        const month = currentDate.getMonth();

        calendar.innerHTML = `
            <div class="calendar-header">
                <button id="prev-month">‹</button>
                <span>${new Date(year, month).toLocaleString('default', { month: 'long', year: 'numeric' })}</span>
                <button id="next-month">›</button>
            </div>
            <div class="calendar-grid">
                <div>Su</div><div>Mo</div><div>Tu</div><div>We</div><div>Th</div><div>Fr</div><div>Sa</div>
            </div>
        `;

        const grid = calendar.querySelector('.calendar-grid');
        const firstDay = new Date(year, month, 1).getDay();
        const lastDay = new Date(year, month + 1, 0).getDate();

        // Add empty cells for days before the first day of the month
        for (let i = 0; i < firstDay; i++) {
            grid.innerHTML += '<div></div>';
        }

        // Add days of the month
        for (let day = 1; day <= lastDay; day++) {
            const dayElement = document.createElement('div');
            dayElement.className = 'calendar-day';
            dayElement.textContent = day;
            dayElement.addEventListener('click', () => {
                const selectedDate = new Date(year, month, day);
                input.value = selectedDate.toISOString().split('T')[0];
                calendar.classList.add('hidden');
            });
            grid.appendChild(dayElement);
        }

        // Add event listeners for month navigation
        calendar.querySelector('#prev-month').addEventListener('click', () => {
            const newDate = new Date(year, month - 1);
            input.value = newDate.toISOString().split('T')[0];
            renderCalendar(calendar, input);
        });

        calendar.querySelector('#next-month').addEventListener('click', () => {
            const newDate = new Date(year, month + 1);
            input.value = newDate.toISOString().split('T')[0];
            renderCalendar(calendar, input);
        });
    }
});
