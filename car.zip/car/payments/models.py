from django.db import models
from django.contrib.auth.models import User
from rentals.models import Rental

class Payment(models.Model):
    PAYMENT_METHOD_CHOICES = [
        ('card', 'Credit/Debit Card'),
        ('upi', 'UPI'),
        ('netbanking', 'Net Banking'),
        ('wallet', 'Wallet'),
        ('cash', 'Cash'),
    ]

    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('completed', 'Completed'),
        ('failed', 'Failed'),
        ('refunded', 'Refunded'),
    ]

    rental = models.OneToOneField(Rental, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    payment_method = models.CharField(max_length=20, choices=PAYMENT_METHOD_CHOICES)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    transaction_id = models.CharField(max_length=100, unique=True)
    payment_gateway_response = models.JSONField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Payment for {self.rental} - {self.status}"

class Refund(models.Model):
    payment = models.OneToOneField(Payment, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    reason = models.TextField()
    status = models.CharField(max_length=20, choices=[
        ('pending', 'Pending'),
        ('processed', 'Processed'),
        ('failed', 'Failed'),
    ], default='pending')
    processed_at = models.DateTimeField(blank=True, null=True)

class Subscription(models.Model):
    PLAN_CHOICES = [
        ('basic', 'Basic'),
        ('premium', 'Premium'),
        ('enterprise', 'Enterprise'),
    ]

    user = models.OneToOneField(User, on_delete=models.CASCADE)
    plan = models.CharField(max_length=20, choices=PLAN_CHOICES)
    start_date = models.DateField()
    end_date = models.DateField()
    auto_renew = models.BooleanField(default=True)
    active = models.BooleanField(default=True)

class WalletTransaction(models.Model):
    TRANSACTION_TYPE_CHOICES = [
        ('credit', 'Credit'),
        ('debit', 'Debit'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    transaction_type = models.CharField(max_length=10, choices=TRANSACTION_TYPE_CHOICES)
    description = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)

class Coupon(models.Model):
    code = models.CharField(max_length=20, unique=True)
    discount_type = models.CharField(max_length=10, choices=[
        ('percentage', 'Percentage'),
        ('fixed', 'Fixed Amount'),
    ])
    discount_value = models.DecimalField(max_digits=10, decimal_places=2)
    min_order_value = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    max_discount = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    valid_from = models.DateTimeField()
    valid_to = models.DateTimeField()
    usage_limit = models.PositiveIntegerField(default=1)
    used_count = models.PositiveIntegerField(default=0)
    active = models.BooleanField(default=True)

class Referral(models.Model):
    referrer = models.ForeignKey(User, on_delete=models.CASCADE, related_name='referrals_made')
    referred = models.OneToOneField(User, on_delete=models.CASCADE, related_name='referred_by')
    code_used = models.CharField(max_length=20)
    reward_given = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)


class PaymentTransaction(models.Model):
    """Detailed payment transaction history"""
    TRANSACTION_TYPE_CHOICES = [
        ('deposit', 'Deposit Payment'),
        ('remaining', 'Remaining Payment'),
        ('full', 'Full Payment'),
        ('refund', 'Refund'),
        ('cancellation_refund', 'Cancellation Refund'),
        ('deposit_refund', 'Deposit Refund'),
    ]
    
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('confirmed', 'Confirmed'),
        ('verified', 'Verified'),
        ('failed', 'Failed'),
        ('cancelled', 'Cancelled'),
    ]
    
    rental = models.ForeignKey(Rental, on_delete=models.CASCADE, related_name='payment_transactions')
    transaction_type = models.CharField(max_length=30, choices=TRANSACTION_TYPE_CHOICES)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    transaction_id = models.CharField(max_length=100, unique=True)
    payment_method = models.CharField(max_length=50, blank=True)
    payment_reference = models.CharField(max_length=100, blank=True, help_text="Payment gateway reference")
    notes = models.TextField(blank=True)
    admin_verified = models.BooleanField(default=False)
    admin_verified_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='verified_payments')
    admin_verified_at = models.DateTimeField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.transaction_type} - ₹{self.amount} - {self.status}"


class PaymentConfirmation(models.Model):
    """Track payment confirmations for deposit and remaining amounts"""
    CONFIRMATION_TYPE_CHOICES = [
        ('deposit', 'Deposit Confirmation'),
        ('remaining', 'Remaining Amount Confirmation'),
        ('full', 'Full Payment Confirmation'),
    ]
    
    rental = models.ForeignKey(Rental, on_delete=models.CASCADE, related_name='payment_confirmations')
    confirmation_type = models.CharField(max_length=20, choices=CONFIRMATION_TYPE_CHOICES)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    is_confirmed = models.BooleanField(default=False)
    confirmed_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='confirmed_payments')
    confirmed_at = models.DateTimeField(blank=True, null=True)
    confirmation_notes = models.TextField(blank=True)
    payment_proof = models.CharField(max_length=200, blank=True, help_text="Payment proof/reference number")
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.confirmation_type} - ₹{self.amount} - {'Confirmed' if self.is_confirmed else 'Pending'}"


class RefundConfirmation(models.Model):
    """Track refund confirmations for cancellations"""
    rental = models.ForeignKey(Rental, on_delete=models.CASCADE, related_name='refund_confirmations')
    refund_type = models.CharField(max_length=30, default='cancellation')
    original_amount = models.DecimalField(max_digits=10, decimal_places=2, help_text="Original amount paid")
    cancellation_charge = models.DecimalField(max_digits=10, decimal_places=2, help_text="10% cancellation charge")
    refund_amount = models.DecimalField(max_digits=10, decimal_places=2, help_text="Amount to be refunded")
    
    # Confirmation fields
    is_confirmed = models.BooleanField(default=False)
    confirmed_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='confirmed_refunds')
    confirmed_at = models.DateTimeField(blank=True, null=True)
    confirmation_notes = models.TextField(blank=True)
    
    # Refund processing fields
    refund_method = models.CharField(max_length=50, blank=True, help_text="Bank transfer, UPI, etc.")
    refund_reference = models.CharField(max_length=100, blank=True, help_text="Refund transaction reference")
    is_processed = models.BooleanField(default=False)
    processed_at = models.DateTimeField(blank=True, null=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"Refund ₹{self.refund_amount} - {'Confirmed' if self.is_confirmed else 'Pending'}"
