from django.db import migrations, models
import django.db.models.deletion
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('rentals', '0009_rental_payment_method'),
        ('payments', '0002_initial'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='PaymentTransaction',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('transaction_type', models.CharField(choices=[('deposit', 'Deposit Payment'), ('remaining', 'Remaining Payment'), ('full', 'Full Payment'), ('refund', 'Refund'), ('cancellation_refund', 'Cancellation Refund'), ('deposit_refund', 'Deposit Refund')], max_length=30)),
                ('amount', models.DecimalField(decimal_places=2, max_digits=10)),
                ('status', models.CharField(choices=[('pending', 'Pending'), ('confirmed', 'Confirmed'), ('verified', 'Verified'), ('failed', 'Failed'), ('cancelled', 'Cancelled')], default='pending', max_length=20)),
                ('transaction_id', models.CharField(max_length=100, unique=True)),
                ('payment_method', models.CharField(blank=True, max_length=50)),
                ('payment_reference', models.CharField(blank=True, help_text='Payment gateway reference', max_length=100)),
                ('notes', models.TextField(blank=True)),
                ('admin_verified', models.BooleanField(default=False)),
                ('admin_verified_at', models.DateTimeField(blank=True, null=True)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('admin_verified_by', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='verified_payments', to=settings.AUTH_USER_MODEL)),
                ('rental', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='payment_transactions', to='rentals.rental')),
            ],
        ),
        migrations.CreateModel(
            name='PaymentConfirmation',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('confirmation_type', models.CharField(choices=[('deposit', 'Deposit Confirmation'), ('remaining', 'Remaining Amount Confirmation'), ('full', 'Full Payment Confirmation')], max_length=20)),
                ('amount', models.DecimalField(decimal_places=2, max_digits=10)),
                ('is_confirmed', models.BooleanField(default=False)),
                ('confirmed_at', models.DateTimeField(blank=True, null=True)),
                ('confirmation_notes', models.TextField(blank=True)),
                ('payment_proof', models.CharField(blank=True, help_text='Payment proof/reference number', max_length=200)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('confirmed_by', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='confirmed_payments', to=settings.AUTH_USER_MODEL)),
                ('rental', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='payment_confirmations', to='rentals.rental')),
            ],
        ),
        migrations.CreateModel(
            name='RefundConfirmation',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('refund_type', models.CharField(default='cancellation', max_length=30)),
                ('original_amount', models.DecimalField(decimal_places=2, help_text='Original amount paid', max_digits=10)),
                ('cancellation_charge', models.DecimalField(decimal_places=2, help_text='10% cancellation charge', max_digits=10)),
                ('refund_amount', models.DecimalField(decimal_places=2, help_text='Amount to be refunded', max_digits=10)),
                ('is_confirmed', models.BooleanField(default=False)),
                ('confirmed_at', models.DateTimeField(blank=True, null=True)),
                ('confirmation_notes', models.TextField(blank=True)),
                ('refund_method', models.CharField(blank=True, help_text='Bank transfer, UPI, etc.', max_length=50)),
                ('refund_reference', models.CharField(blank=True, help_text='Refund transaction reference', max_length=100)),
                ('is_processed', models.BooleanField(default=False)),
                ('processed_at', models.DateTimeField(blank=True, null=True)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('confirmed_by', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='confirmed_refunds', to=settings.AUTH_USER_MODEL)),
                ('rental', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='refund_confirmations', to='rentals.rental')),
            ],
        ),
    ]
