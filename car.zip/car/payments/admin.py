from django.contrib import admin
from .models import PaymentConfirmation

# Register existing models
@admin.register(PaymentConfirmation)
class PaymentConfirmationAdmin(admin.ModelAdmin):
    list_display = ['rental', 'confirmation_type', 'amount', 'is_confirmed', 'confirmed_by', 'confirmed_at']
    list_filter = ['confirmation_type', 'is_confirmed']
